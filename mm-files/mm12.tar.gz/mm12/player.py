"""
Player class definition and custom subclasses for Mechmania 12

Herein is defined the basic Player class, which defines the abstract
attributes that all Players should have.
"""

BAD_CHARS='\n;\x00'

class Player:
    """
    The basic class definition of a Player, representing the player's current
    in-game state.
    """
    
    START_SOFTWARE = 100 # How much software is available at this player's pier
    
    def __init__(self, id=-1, pier_loc=(0,0), color=(0,0,0)):
        """
        Initialize the player with an id and the location of this player's pier.
        """
        self.software = self.START_SOFTWARE
        self.id = id
        self.pier = pier_loc
        self.color = color
        self.name = 'Unnamed team'
        self.reset_state()

    def reset_state(self):
        self.trash_talk = []
        
    def command_name(self, name):
        if self.name == 'Unnamed team':
            self.name = name.strip(BAD_CHARS)
        return True

    def command_trashtalk(self, text):
        self.trash_talk.append(text.strip(BAD_CHARS))
        return True
