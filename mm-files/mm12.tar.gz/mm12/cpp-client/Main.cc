#include <iostream>

#include "TCPConnectTo.h"
#include "StateMessage.h"
#include "OrdersMessage.h"
#include "MMPlayer.h"

class NullOrdersException { };

int playerNumber;

void pre(int fd)
{
	// Client sends "player" or "observer"
	writeToSock("player", fd);

	// Server replies with the player number
	// before sending the first state message
	Packet pkt(fd);
	Item it = Item(Line(pkt));
	playerNumber = it.readInt();
}

int main(int argc, char **argv)
{
	if (argc != 3) {
		std::cerr << "Usage: " << argv[0] << " <server-host> <server-port>" << std::endl;
		return 1;
	}

	int fd = connectTo(argv[1], atoi(argv[2]));
	pre(fd);
	Client* client = new MMPlayer(playerNumber);
	
	bool playing = true;
	bool firstTime = true;
	while (playing) {
		// Read the StateMessage from the server.
		Packet pkt(fd);
		StateMessage sm = StateMessage(pkt);
		if ((sm.game->status == 2) && (sm.game->tm == sm.game->maxTm))
			playing = false;
		
		// Associate an OrdersQueue with each Boat.
		OrdersQueue *oq = OrdersQueue::create();
		for (std::vector<Boat *>::iterator i = sm.boats.begin(); i != sm.boats.end(); i++)
			(*i)->setOrdersQueue(oq);
		for (std::vector<Player *>::iterator i = sm.players.begin(); i != sm.players.end(); i++) {
			if ((*i)->id == playerNumber)
				(*i)->setOrdersQueue(oq);
		}
		
		// CALL THE CLIENT.
		client->updateState(sm);
		if (firstTime) {
			client->init();
			firstTime = false;
		}
		client->tick();
		
		// Retrieve the orders the client wants to send.
		OrdersQueueImpl *oqi = dynamic_cast<OrdersQueueImpl *>(oq);
		if (oqi == NULL)
			throw NullOrdersException();
		// Send the OrdersMessage to the server.
		oqi->sendOrders(fd);
		// Deallocate all OrderQueues allocated in this round.
		deallocOrders();
	}

	delete client;

	return 0;
}
