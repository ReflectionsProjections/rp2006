/**
 * \file Geom.h
 * \brief This contains some helper functions for basic geometry
 */
#ifndef __GEOM__H__
#define __GEOM__H__

#include "Model.h"
#include <cmath>

#define PI 3.14159

/**
 * \fn double rad2deg(double radVal)
 * \param radVal a radian
 * \return a degree
 * \brief converts a radian value to a degree
 */
double rad2deg(double radVal);

/**
 * \fn double deg2rad(double degVal)
 * \param degVal a degree
 * \return a radian
 * \brief converts a degree to its radian value
 */
double deg2rad(double degVal);

/**
 * \fn double angleBetween(const Coord& src, const Coord& dest)
 * \param src 
 * \param dest
 * \return the angle between src and dest
 * \brief finds the angle between two coordinates
 */
double angleBetween(const Coord& src, const Coord& dest);

/**
 * \fn double dist(const Coord &p1, const Coord &p2)
 * \param p1
 * \param p2
 * \return the distance between p1 and p2
 * \brief finds the distance between two points
 */
double dist(const Coord& p1, const Coord& p2);

#endif
