#include "StateMessage.h"

// Read in various objects out of messages.

static Item readBoat(Item itm, Boat *b)
{
	b->player       = itm.readInt();   itm++;
	b->id           = itm.readInt();   itm++;
	b->location     = itm.readCoord(); itm++;
	b->heading      = itm.readFloat(); itm++;
	b->goalHeading  = itm.readFloat(); itm++;
	b->health       = itm.readFloat(); itm++;
	b->speed        = itm.readFloat(); itm++;
	// TODO
	//itm.readCoordList(&b->damagePoints); itm++;
	itm.readTuple(&b->collidesWith);   itm++;
	return itm;
}

static Item readPirateBoat(Item itm, PirateBoat *pb)
{
	itm = readBoat(itm, pb);
	pb->software = itm.readFloat();    itm++;
	itm.readTuple(&pb->fireAngle);     itm++;
	itm.readTuple(&pb->fireDamage);    itm++;
	itm.readTuple(&pb->fireRange);     itm++;
	itm.readTuple(&pb->fireWait);      itm++;
	itm.readTuple(&pb->fire);          itm++;
	return itm;
}

static Item readRumRunner(Item itm, RumRunner *rb)
{
	itm = readBoat(itm, rb);
	return itm;
}

static Item readGame(Item itm, Game *g)
{
	g->tm     = itm.readInt(); itm++;
	g->maxTm  = itm.readInt(); itm++;
	g->status = itm.readInt(); itm++;
	g->winner = itm.readInt(); itm++;
	return itm;
}

static Item readPlayer(Item itm, Player *p)
{
	p->id       = itm.readInt();   itm++;
	p->software = itm.readFloat(); itm++;
	p->pier     = itm.readCoord(); itm++;
	itm.readTuple(&p->color);      itm++;
	p->name     = itm.readStr();   itm++;
	return itm;
}

StateMessage::StateMessage(Packet &pkt)
{
	Line ln(pkt);
	Item itm;

	// Read game
	if (Item(ln).readInt() != 1)
		throw StateMessageException();
	ln++;
	itm = Item(ln);
	itm.isString("Game");
	itm++;
	game = new Game();
	readGame(itm, game);
	ln++;

	// Read players
	if (Item(ln).readInt() != 0)
		throw StateMessageException();
	ln++;
	int numPlayers = Item(ln).readInt();
	ln++;
	while (numPlayers > 0) {
		itm = Item(ln);
		itm.isString("Player");
		itm++;
		Player *p = new Player();
		readPlayer(itm, p);
		players.push_back(p);
		ln++;
		numPlayers--;
	}

	// Read boats
	if (Item(ln).readInt() != 0)
		throw StateMessageException();
	ln++;
	int numBoats = Item(ln).readInt();
	ln++;
	while(numBoats > 0) {
		itm = Item(ln);
		if (itm.isString("PirateBoat")) {
			itm++;
			PirateBoat *pb = new PirateBoat();
			readPirateBoat(itm, pb);
			boats.push_back(pb);
		}
		else if (itm.isString("RumRunner")) {
			itm++;
			RumRunner *rb = new RumRunner();
			readRumRunner(itm, rb);
			boats.push_back(rb);
		}
		else throw StateMessageException();
		ln++;
		numBoats--;
	}

//	std::cout << boats[3]->speed << std::endl;
}

StateMessage::~StateMessage()
{
	if (game)
		delete game;
	game = NULL;
	for (std::vector<Player *>::iterator i = players.begin(); i != players.end(); i++)
		if (*i)
			delete *i;
	players.clear();
	for (std::vector<Boat *>::iterator i = boats.begin(); i != boats.end(); i++)
		if (*i)
			delete *i;
	boats.clear();
}
