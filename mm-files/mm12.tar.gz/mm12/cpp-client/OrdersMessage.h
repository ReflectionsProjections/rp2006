#ifndef	__ORDERS_MESSAGE__H__
#define	__ORDERS_MESSAGE__H__

#include "OrdersQueue.h"
#include "TCPConnectTo.h"

std::string join(std::string sep, std::vector<std::string> strs);

class OrdersQueueImpl : public OrdersQueue {
private:
	class Order {
	public:
		std::string name;
		Args args;

		Order(std::string name, Args args) : name(name), args(args)
		{	}
	};

	std::vector<Order> orders;
public:
	virtual ~OrdersQueueImpl()
	{	}

	std::string getOrders()
	{
		std::string ordStr;
		std::vector<Order>::iterator i;
		Args::iterator j;
		// Concatenate all orders
		for (i = orders.begin(); i != orders.end(); i++) {
			// Name
			ordStr += i->name;
			ordStr += ' ';
			// Args
			ordStr += join(";", i->args);
			// Newline
			ordStr += '\n';
		}
		return ordStr;
	}

	void sendOrders(int fd)
	{
		writeToSock(getOrders(), fd);
	}

	void add(std::string name)
	{
		orders.push_back(Order(name, Args()));
	}
	void add(std::string name, std::string arg0)
	{
		orders.push_back(Order(name, Args(1, arg0)));
	}
	void add(std::string name, std::string arg0, std::string arg1)
	{
		orders.push_back(Order(name, Args()));
		orders.back().args.push_back(arg0);
		orders.back().args.push_back(arg1);
	}
	void add(std::string name, Args args)
	{
		orders.push_back(Order(name, args));
	}
};

void deallocOrders();

#endif	// __ORDERS_MESSAGE__H__
