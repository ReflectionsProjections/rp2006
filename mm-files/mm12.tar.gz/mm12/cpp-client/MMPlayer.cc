#include "MMPlayer.h"
#include "Model.h"
#include <iostream>

using namespace std;

#define NUM_SOFTWARES_TO_STEAL_FROM_ENEMY 100.0

bool
isBoatAt(Boat *boat, const Coord& location)
{
	return (abs(boat->location.x - location.x) < 2 &&
		abs(boat->location.y - location.y) < 2);
}

void
MMPlayer::init()
{
	// TODO: set your team name
	me->setName("Your team name goes here");

	// TODO: set some initial trash talk ;)
	me->trashTalk("w00t!");

	// TODO: set some other initial state
}

// Test client that just prints out (most of) its state.
void
MMPlayer::tick()
{
  //printState();

	// for every pirate boat we have run pirate boat routine
	for (vector<PirateBoat*>::iterator it = myPBoats.begin();
		it != myPBoats.end(); ++it)
	{
		runPirateBoatRountine(*it);
	}
}

void
MMPlayer::dance(Boat *boat)
{
	// Example action function
	// TODO: implement a dancing function if you like :)
	cout << "I, Mr. Boat #" << boat->id << ", am dancing!" << endl;
}

void
MMPlayer::runPirateBoatRountine(PirateBoat *boat)
{
	// every twenty rounds
	// DANCE!!!
	if (game->tm % 20 == 0)
		dance(boat);

	// if we are at the enemy pier
	// STEAL THEIR SOFTWARE!!!
	else if (isBoatAt(boat, enemy->pier))
		boat->load(NUM_SOFTWARES_TO_STEAL_FROM_ENEMY);

	// if we are at the player pier and we have software
	// UNLOAD ALL OF IT!!!
	else if (isBoatAt(boat, me->pier))
		boat->unload(boat->software);

	else // move to a pier as needed
	{
		Coord target;

		// see if we have any software
		if (boat->software > 0.0)
			// if yes, change angle toward port
			target = me->pier;

		else
			// else, change angle toward enemy pier
			target = enemy->pier;

		// now "aim" towards our target
		boat->turnAbsolute(
			angleBetween(boat->location, target));

		// head towards target at maximum velocity without
		// overshooting it (if over max velocity, I believe that there
		// shouldn't be any issues)
		Coord from = boat->location;
		double appropriateVelocity = sqrt(pow(target.x-from.x, 2) + pow(target.y-from.y,2));
		boat->velocity(appropriateVelocity);
	}
}

void
MMPlayer::printState()
{
	cout << "State" << endl;

	cout << "\tGame" << endl;
		cout << "\t\ttm:     " << game->tm     << endl;
		cout << "\t\tmaxTm:  " << game->maxTm  << endl;
		cout << "\t\tstatus: " << game->status << endl;
		cout << "\t\twinner: " << game->winner << endl;

	cout << "\tPlayers" << endl;
	for (vector<Player *>::iterator it = players.begin(); it != players.end(); it++)
	{
		cout << "\t\tid: " << (*it)->id << endl;
		cout << "\t\t\tsoftware: " << (*it)->software << endl;
		cout << "\t\t\tpier:     (" << (*it)->pier.x << ", " << (*it)->pier.y << ")" << endl;
	}

	cout << "\tBoats" << endl;
	for (vector<Boat *>::iterator it = allBoats.begin(); it != allBoats.end(); it++)
	{
		cout << "\t\tplayer: " << (*it)->player << endl;
		cout << "\t\tid:     " << (*it)->id     << endl;
		cout << "\t\t\tlocation:    (" << (*it)->location.x << ", " << (*it)->location.y << ")" << endl;
		cout << "\t\t\theading:     "  << (*it)->heading << endl;
		cout << "\t\t\tgoalHeading: "  << (*it)->goalHeading << endl;
		cout << "\t\t\thealth:      "  << (*it)->health << endl;
		cout << "\t\t\tspeed:       "  << (*it)->speed << endl;
		cout << "\t\t\tfireWait, fire, collidesWith: ..." << endl;
	}
}
