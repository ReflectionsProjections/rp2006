#include "OrdersMessage.h"

std::string join(std::string sep, std::vector<std::string> strs)
{
	std::string s;
	bool first = true;
	for (std::vector<std::string>::iterator i = strs.begin(); i != strs.end(); i++) {
		if (!first)
			s += sep;
		first = false;
		s += *i;
	}
	return s;
}

static std::vector<OrdersQueue *> allOrders;

OrdersQueue *OrdersQueue::create()
{
	OrdersQueue *oq = new OrdersQueueImpl();
	allOrders.push_back(oq);
	return oq;
}

void deallocOrders()
{
	for (std::vector<OrdersQueue *>::iterator i = allOrders.begin(); i != allOrders.end(); i++)
		delete *i;
	allOrders.clear();
}
