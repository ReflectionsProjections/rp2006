#include "Geom.h"

double rad2deg(double radVal) {
	return radVal*180/PI;
}

double deg2rad(double degVal) {
	return degVal*PI/180;
}

double angleBetween(const Coord& src, const Coord& dest) {
	return fmod(rad2deg(atan2(dest.y - src.y, dest.x - src.x)), 360);
}

double dist(const Coord& p1, const Coord& p2) {
	return sqrt(pow(p2.x-p1.x, 2) + pow(p2.y-p1.y, 2));
}
