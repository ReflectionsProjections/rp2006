#ifndef __MMPLAYER__H__
#define __MMPLAYER__H__

#include "Client.h"
#include "Geom.h"

class MMPlayer : public Client {
  public:
	MMPlayer(int pNumber) : Client(pNumber) { }
	
	/**
	 * \brief This function will be called at the beginning of the game.
	 *
	 * You can implement this function if you want to do any sort of
	 * pre-game setup.
	 *
	 * This function does have access to the initial game state. If you want
	 * to give certain orders only on the first turn,
	 * you can do so in this function.
	 */
	void init();
	
	/**
	 * \brief This function is called every 'frame' of the game.
	 *
	 * This is where you should be writing all of your code.
	 */
	void tick();

private:
	// data structures

	// functions
	void dance(Boat *boat);
	void runPirateBoatRountine(PirateBoat *boat);

	void printState();
};

#endif
