import socket

HOST = 'localhost'
PORT = 1337

# Note: Both the client and the server code assume in NUMEROUS places
# that we have two players, numbered 0 and 1.

class GameError(Exception):
    pass

class GameComplete(Exception):
    pass

class SocketError(Exception):
    pass

# We send the length with each message to ensure that we don't
# accidentally get either part of a message or
# multiple messages strung together.
class SocketWrapper:
    def __init__(self, conn, timeout=0):
        self.conn = conn
        if timeout > 0:
            print 'Set socket timeout to', timeout
            self.conn.settimeout(timeout)
        
    def send(self, data):
        length = '%10d' % (len(data))
        try:
            self.conn.send(length)
            #print '>>> %s: %s' % (length, data[:40])
            self.conn.send(data)
        except socket.error:
            # TODO: for production, catch everything, not just socket.error
            raise SocketError('Error sending data')

    def recv(self):
        # Are we trusting the client here? Not really,
        # as long as our socket has a timeout attached:
        # we treat a stall or exception as a win for the other player.
        # It's possible that some exception that we don't catch here
        # could be propagated; for production use, we should just
        # catch everything and blame it on the player responsible.
        try:
            length = int(self.conn.recv(10))
            if length == 0:
                return ''
            return self.conn.recv(length)
            #data = self.conn.recv(length)
            #print '<<< %d: %s' % (length, data[:40])
            #return data
        except (ValueError, socket.timeout), e: # server disconnected on us?
            raise SocketError('Error or timeout receiving data')

    def close(self):
        # For completeness of wrapping API
        self.conn.close()
