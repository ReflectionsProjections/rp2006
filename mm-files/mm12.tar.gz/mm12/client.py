#!/usr/bin/python2.4

import sys
import socket

import net
import game

# For pretending to be a slow client
import random
import time

class GameClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        sock = socket.socket()
        sock.connect((host, port))
        self._conn = net.SocketWrapper(sock)

    def wait_for_next_turn(self):
        #print 'waiting for next turn'
        s = self._conn.recv()
        # Returns a (game, players, boats) tuple
        return game.unserialize_state(s)

class ObserverClient(GameClient):
    def __init__(self, host, port):
        GameClient.__init__(self, host, port)
        self._conn.send('observer')
        assert self._conn.recv() == 'ok'

class PlayerClient(GameClient):
    def __init__(self, host, port):
        GameClient.__init__(self, host, port)
        self._conn.send('player')
        self.player_id = int(self._conn.recv())
        
    def send_orders(self, order_list):
        print 'About to send orders:'
        print order_list
        # Pretend to be a slow client
        #if random.random() < .1:
        #    time.sleep(2.2)
        self._conn.send('\n'.join(order_list))



def main():
    import ai
    
    if len(sys.argv) < 2:
        print 'Usage: python client.py PlayerClass [host_name] [port]'
        sys.exit()
    player_name = sys.argv[1]
    if len(sys.argv) >= 3:
        host = sys.argv[2]
    else:
        host = net.HOST
    if len(sys.argv) >= 4:
        port = int(sys.argv[3])
    else:
        port = net.PORT

    PlayerClass = getattr(ai, player_name)
    client = PlayerClient(host, port)
    p = PlayerClass(client.player_id)
    while True:
        game, players, boats = client.wait_for_next_turn()
        if game.status == game.DONE:
            print 'Game done'
            if game.winner == -1:
                print 'Tie game'
            else:
                print 'Winner: player', game.winner
            break
        client.send_orders(p.give_orders(game, players, boats))

if __name__=='__main__':
    main()
