#!/usr/bin/python2.3

import sys
import socket
import threading
import Queue
import time
import optparse

import net
import player
import game

class GameServer:
    def __init__(self, host, port, game, delay):
        self.host = host
        self.port = port
        self._sock = socket.socket()
        # Prevent 'Address already in use' errors
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.listen(2)
        self.clients = []
        self.order_q = Queue.Queue()
        self.game = game
        self.turn_delay = delay

    def serve_forever(self):
        # Note: observers must connect before the game starts
        while self.game.num_players < 2:
            client_sock, addr = self._sock.accept()
            conn = net.SocketWrapper(client_sock, timeout=0.5) # in seconds
            try:
                client_type = conn.recv()
            except net.SocketError:
                continue
            if client_type == 'player':
                print 'Player connected'
                p_id = self.game.add_player()
                conn.send(str(p_id))
                self.clients.append(PlayerThread(conn, p_id, self.order_q))
            elif client_type == 'observer':
                print 'Observer connected'
                conn.send('ok')
                self.clients.append(ObserverThread(conn))
            else:
                print 'Ignoring unknown client'
                conn.close()
                continue
                
        #self.game.start_game()
        
        while self.game.status == self.game.RUNNING:
            print 'Turn', self.game.tm
            state = self.game.state()
            #print state
            for client in self.clients:
                # "False" means that the game is not done.
                client.state_q.put((state, False))
            orders = {}
            for i in range(2):
                # No timeout here: the client thread is in charge of
                # waiting for the appropriate amount of time
                p_id, order_lst = self.order_q.get(True)
                if order_lst is None:
                    # For now, simply declare the other player as the winner
                    self.game.end_game((p_id+1)%2)
                    print 'client',p_id,'timed out'
                    break
                orders[p_id] = order_lst.split('\n')
            self.game.next_turn(orders)
            if self.turn_delay > 0:
                time.sleep(self.turn_delay / 1000)
            
        # Clean up
        print 'Game done'
        print 'winner', self.game.winner
        final_state = self.game.state()
        for client in self.clients:
            # Communicate the final state of the game to clients
            # so that they know who won.
            # The "True" argument means that the game is done
            # and the client thread should close the socket.
            client.state_q.put((final_state, True))
            # TODO: kill the client thread in case it is hung trying to
            # send to the client.
        self._sock.close()

class ClientThread(threading.Thread):
    def __init__(self, conn):
        threading.Thread.__init__(self)

        self._conn = conn
        self.state_q = Queue.Queue()
        
        self.start()

    def send_state(self):
        """Wait for the next turn's game state, then send that to the client.
        Returns True if the game is done."""
        state, game_done = self.state_q.get()
        try:
            self._conn.send(state)
        except net.SocketError:
            # From the perspective of ClientThread, this is equivalent
            # to the game ending.
            return False
        return game_done
            
class PlayerThread(ClientThread):
    def __init__(self, conn, player_id, order_q):
        self.id = player_id
        self.order_q = order_q
        
        ClientThread.__init__(self, conn)

    def recv_orders(self):
        '''Wait for orders from the client, then pass those to the game.
        Returns False if the client disconnected or timed out.'''
        try:
            orders = self._conn.recv()
        except Exception, e:
            print 'Giving up on client', self.id
            print 'Reason:', e
            self.order_q.put((self.id, None)) # Tell the server we've left
            return False
        else:
            self.order_q.put((self.id, orders))
            return True
        
    def run(self):
        while True:
            game_done = self.send_state()
            if game_done:
                print 'Closing player socket', self.id
                break
            success = self.recv_orders()
            if not success: # Did not receive orders from client
                break
            
        self._conn.close()

class ObserverThread(ClientThread):
    def run(self):
        while True:
            game_done = self.send_state()
            if game_done:
                print 'Closing observer socket'
                break
            
        self._conn.close()
        
def main():
    # This should really use optparse
    parser = optparse.OptionParser()
    parser.add_option('-p', '--port', type='int', default=net.PORT,
                      help='listen on PORT')
    parser.add_option('-n', '--num-turns', type='int', default=300,
                      help='run for NUM_TURNS turns')
    parser.add_option('-d', '--delay', type='float', default=0,
                      help='wait for DELAY ms between turns')
    parser.add_option('--remote', action='store_true', default=True,
                      help='allow non-local clients to connect')
    options, args = parser.parse_args()
    if hasattr(options, 'remote') and options.remote == True:
        host = ''
    else:
        host = 'localhost'
    
    g = game.Game(options.num_turns)
    serv = GameServer(host, options.port, g, options.delay)
    try:
        serv.serve_forever()
    finally:
        serv._sock.close()
    # The following exit codes can occur:
    # 1 - uncaught exception
    # 9 - tie
    # 10 - player 0 wins
    # 11 - player 1 wins
    sys.exit(10 + g.winner)
    
if __name__=='__main__':
    main()
