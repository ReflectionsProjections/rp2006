#!/usr/bin/python

import os
import time
import sys
import signal

def run(cmd, args=[]):
    #return subprocess.Popen([cmd] + args) # requires python2.4
    return os.spawnv(os.P_NOWAIT, cmd, [cmd] + args)

def run_script(args):
    return os.spawnv(os.P_NOWAIT, '/usr/bin/python2.3', ['python'] + args)

usage = '''Usage: ./run.py path/to/player1 [path/to/player2]

If player2 is omitted, player1 will play against itself.
'''

try:
    p1_path = sys.argv[1]
except:
    print usage
    sys.exit()
try:
    p2_path = sys.argv[2]
except IndexError:
    p2_path = p1_path

server = viz = p1 = p2 = -1
try:
    server = run_script(['server.pyc'])
    time.sleep(.5) # give server time to begin accepting connections
    viz = run_script(['visualizer.pyc', 'remote', 'localhost', '1337'])
    time.sleep(.5)
    p1 = run(p1_path, ['localhost', '1337'])
    time.sleep(.5)
    p2 = run(p2_path, ['localhost', '1337'])
    ret = os.WEXITSTATUS(os.waitpid(server, 0)[1])
    print ret
    time.sleep(2)
    time.sleep(2) # give time to show winner
finally:
    for child in server, viz, p1, p2:
        if child != -1:
            try:
                print 'killing', child
                os.kill(child, signal.SIGHUP)
            except os.error: # no such process, which is ok, too
                pass
