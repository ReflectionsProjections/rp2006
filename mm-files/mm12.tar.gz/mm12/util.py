# Miscellaneous trig functions and whatnot

import math

# Note that our compass has 0 at due East, increasing counterclockwise
# (e.g. 90=North, etc.)
    
# If we switch to pirate ships in space, this will be the only
# function that does not have to be recoded.
def distance(p1, p2):
    return math.sqrt(sum([(a-b)**2 for a, b in zip(p1, p2)]))

def magnitude(pt):
    return math.sqrt(sum([n**2 for n in pt]))

def angle_between(source, dest):
    """Determine the heading that the point at source should set to
    move towards point dest."""
    dy = dest[1] - source[1]
    dx = dest[0] - source[0]
    return math.degrees(math.atan2(dy, dx)) % 360

# Some calculations are duplicated in these functions,
# but most of them are minor (e.g. finding the slope twice).
# Let's not mess with them unless speed becomes a problem.

def cast_ray(pt, angle, max_dist, rects):
    """Given a point, an angle, the maximum distance we can reach,
    and a dictionary of key->rectangle,
    return the key for the first rectangle that we would hit."""
    # Construct line segment from pt, angle, and max_dist
    theta = math.radians(angle)
    pt2 = add(pt, (max_dist*math.cos(theta), max_dist*math.sin(theta)))
    line = (pt, pt2)
    
    hits = []
    min_key = None
    min_val = 1e106
    for key, rect in rects.iteritems():
        edges = [(rect[i], rect[(i+1)%4]) for i in range(4)]
        for i in range(4):
            try:
                hit = segment_intersection(edges[i], line)
            except ZeroDivisionError:
                # If the ray is parallel to this rectangle edge,
                # it definitely does not intersect it
                continue
            if hit is not None:
                dist = distance(hit, pt)
                if dist < min_val:
                    min_key = dist
                    min_key = key
    return min_key

def segment_intersection(l1, l2):
    pt = intersection(l1, l2)
    if within(pt, l1) and within(pt, l2):
        return pt
    else:
        return None

def within(pt, line):
    c1, c2 = line[0][0], line[1][0] # extract x-coords
    if c1 == c2: # lines are vertical, so use y-coords
        c1, c2 = line[0][1], line[1][1]
        test = pt[1]
    else:
        test = pt[0]
    if c1 > c2:
        c1, c2 = c2, c1
    return c1 < test < c2

def intersection(l1, l2):
    """Returns the intersection point of two lines,
    each defined as a pair of points.
    
    Raises a ZeroDivisionError if the lines are parallel."""

    try:
        m1 = slope(*l1)
    except ZeroDivisionError:
        return _vert_intersect(l2, l1[0][0]) # extract x-coord of l1
    try:
        m2 = slope(*l2)
    except ZeroDivisionError:
        return _vert_intersect(l1, l2[0][0])
    b1 = intercept(l1[0], m1)
    b2 = intercept(l2[0], m2)
    x = (b2 - b1) / (m1 - m2)
    y = m1*x + b1
    return x, y

def _vert_intersect(line, x_naught):
    """Determines the point of interception between a skew line
    and a vertical line defined by x=x_naught.
    
    Raises a ZeroDivisionError if the other line is also vertical."""
    m = slope(*line)
    return (x_naught, m*x_naught + intercept(line[0], m))

def slope(p1, p2):
    return (p2[1] - p1[1]) / (p2[0] - p1[0])

def intercept(point, slope):
    return point[1] - slope*point[0]

def center(points):
    """Return the centroid of a collection of points."""
    return (sum([p[0] for p in points]) / len(points),
            sum([p[1] for p in points]) / len(points))

def rect(center, w, h, angle=0):
    """Construct a rectangle given its center, width, height,
    and optional rotation in degrees."""
    x, y = center
    theta = math.radians(angle)
    return [add(center, rotate((-w/2, -h/2), theta)),
            add(center, rotate((-w/2,  h/2), theta)),
            add(center, rotate(( w/2,  h/2), theta)),
            add(center, rotate(( w/2, -h/2), theta))]

def in_half_space(a, n, p):
    """Determine whether point p is on the positive side of the line
    through a with normal n.  Each of a, n, and p is a pair (x, y)."""
    return ((p[0]-a[0])*n[0] + (p[1]-a[1])*n[1]) >= 0

def add(pt1, pt2):
    return (pt1[0]+pt2[0], pt1[1]+pt2[1])

def sub(pt1, pt2):
    return (pt1[0]-pt2[0], pt1[1]-pt2[1])

def scale(pt, factor):
    return (factor*pt[0], factor*pt[1])

def collides(r, s):
    """Determines whether rectangles r and s touch or intersect.
    Each rectangle is represented as a list of corner points
    in counter-clockwise order.  Each point is represented as
    a pair (x, y)."""
    # For each edge of the first rectangle
    edges = [(r[i], r[(i+1)%4]) for i in range(4)]
    for p1, p2 in edges:
        # Is there at least one point in the second rectangle
        # on the positive side of the given edge?
        b = False
        for p in s:
            if in_half_space(p1, sub(p2,p1), p):
                b = True
                break
        if not b:
            return False
    return True

def pt_collides(pt, rect):
    """Determines whether pt lies within a given rectangle.

    Currently only tested on rectangles generated by rect(), above;
    probably has the same constraints as collides()."""
    edges = [(rect[i], rect[(i+1)%4]) for i in range(4)]
    for p1, p2 in edges:
        if not in_half_space(p1, sub(p2,p1), pt):
            return False
    return True

def rotate(pt, angle):
	"""Rotate the given point vector pt about the origin by angle radians."""
	cosa = math.cos(angle)
	sina = math.sin(angle)
	return (cosa*pt[0] - sina*pt[1], sina*pt[0] + cosa*pt[1])

#duplicates math.radians
#def degrees_to_radians(deg):
#	return math.pi*deg/180
