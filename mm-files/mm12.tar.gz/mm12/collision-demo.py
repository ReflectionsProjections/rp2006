# Load pygame libraries
import pygame
from pygame.locals import *
if not pygame.font: print "Warning, fonts are disabled"
if not pygame.mixer: print "Warning, sounds are disabled"
import time

import util

resolution = (640, 480)

def game_to_screen(pt):
    return ((pt[0] + 100) * (resolution[0]/200.),
            (pt[1] + 100) * (resolution[1]/200.))

pygame.init()
window = pygame.display.set_mode(resolution)
screen = pygame.display.get_surface()

r1 = [(14.766515182761381, -3.5362765213316765), (15.182820624583947, 6.4550542098126451), (17.181086770812811, 6.3717931214481327), (16.764781328990246, -3.6195376096961889)]

r2 = [(6.1135949339854472, -2.4551105591156981), (9.5337963672421342, -11.852036766974784), (7.6544111256703173, -12.536077053626119), (4.2342096924136303, -3.139150845767035)]

print util.collides(r1, r2)

pygame.draw.polygon(screen, (0, 255, 0), [game_to_screen(pt) for pt in r1])
pygame.draw.polygon(screen, (0, 255, 0), [game_to_screen(pt) for pt in r2])
pygame.display.flip()
while 1:
    time.sleep(1)
