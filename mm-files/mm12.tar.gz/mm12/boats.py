import math
import util

# Make Python 2.3 look like python 2.4
from sets import Set
class set(Set):
    """
    No, we can't just use 'set=Set'; we also need str(set())
    to be 'set(...)' and not 'Set(...)'
    """
    pass

_next_boat_id = -1
def next_boat_id():
    global _next_boat_id
    
    _next_boat_id += 1
    return _next_boat_id

BOAT = 0
PIRATEBOAT = 1
DOCTORBOAT = 2

class Boat:
    # Of course, specifying TYPE here is a gross violation of how to do
    # OOP inheritance. We do so, however, to make it easier for the client
    # to make decisions based on the type of boat.
    TYPE = BOAT

    # Subclasses should define all of these
    TURN_SPEED = 10.0  # degrees per timestep
    ACCEL_SPEED = .5 # units of velocity per timestep
    MAX_SPEED = 2.0
    MAX_HEALTH = 100.0
    INITIAL_HEALTH = 90.0
    # Note that width is the x-span when the boat is at
    # heading=0, i.e. pointing East. This corresponds to the boat's *length*.
    # This is counterintuitive, but I'm not sure the best way to fix it.
    WIDTH = 10
    HEIGHT = 2
    
    # How much the max speed is reduced per unit of software carried
    CARGO_SLOWDOWN = .1
    
    def __init__(self, bid=-1, player_id=-1,
                 location=(0.0, 0.0), heading=90.0):
        if bid == -1:
            self.id = next_boat_id()
        self.location = location
        # heading goes from 0 to 360,
        # starting from East and increasing counterclockwise
        self.heading = heading

        self.health = Boat.INITIAL_HEALTH
        
        self.velocity = 0.0
        self.player = player_id
        self.software = 0.0
        
        self.goal_heading = self.heading
        self.goal_velocity = 0

        # The server will manipulate this if we have hit something
        self.collides_with = set()

    def __str__(self):
        return 'Boat %d: loc=%s, vel=%f, heading=%f' % (
            self.id, self.location, self.velocity, self.heading)

    def vertices(self):
        """Returns a list of tuples for the 4 corners of the boat,
        in consecutive counter-clockwise order."""
        return util.rect(self.location, self.WIDTH, self.HEIGHT,
                         self.heading)

    def _get_damage_points(self):
        '''Return the "pointy parts" of the boat. If the returned points
        collide with another object, that object should be dealt damage.

        We return the front vertices of the boat.
        '''
        return self.vertices()[2:]
    damage_points = property(_get_damage_points)

    def velocity_vector(self):
        angle = math.radians(self.heading)
        return self.velocity*math.cos(angle), self.velocity*math.sin(angle)
        
    # KISS suggests that we probably don't need both
    # turn_absolute and turn_relative. If someone wants to implement,
    # though, feel free.
    def command_turn_absolute(self, goal_heading):
        """Turns the boat to goal_heading degrees, regardless of its current heading"""
        self.goal_heading = goal_heading
        return True
        
    def command_stop_turning(self):
        """Stops turning"""
        self.goal_heading = self.heading
        return True

    def command_velocity(self, goal_velocity):
        """Sets velocity to goal_velocity, regardless of its current speed"""
        self.goal_velocity = goal_velocity
        return True

    def reset_state(self):
        """
        Reset a boat's state and requests (e.g. boarding, loading, etc.)
        for the beginning of a new turn.
        """
        self.collides_with.clear()
        
    def update(self):
        """Actually perform whatever action we think we are performing.

        This is after the server has already gone through and resolved
        any conflicts.
        """

        # Turn if necessary
        if self.goal_heading != self.heading:
            diff = (self.goal_heading - self.heading)%360
            if diff < 180:
                self.heading = (self.heading + self.TURN_SPEED) % 360
            else:
                self.heading = (self.heading - self.TURN_SPEED) % 360
             # Check for overturning
            if (diff < self.TURN_SPEED) or (360 - diff < self.TURN_SPEED):
                self.heading = self.goal_heading
        
        # Accelerate/decelerate if necessary
        if self.goal_velocity > self.velocity:
            self.velocity = min(self.velocity + self.ACCEL_SPEED,
                                self.goal_velocity)
        elif self.goal_velocity < self.velocity:
            self.velocity = max(self.velocity - self.ACCEL_SPEED,
                                self.goal_velocity)

        # Adjust velocity based on damage taken and software carried
        self.velocity = min(
            self.velocity,
            self.MAX_SPEED * (self.health/self.MAX_HEALTH),
            self.MAX_SPEED - self.software * self.CARGO_SLOWDOWN)
        self.velocity = max(self.velocity, 0) # Sanity check
        
        # Move (the server will handle collisions for us)
        if self.velocity > 0:
            self.location = util.add(self.location, self.velocity_vector())

        # Loading, unloading, and boarding
        # are handled by the game itself.

    def sanity_check(self):
        assert self.velocity >= 0 and self.velocity <= self.MAX_SPEED
        assert self.health >= 0 and self.health <= self.MAX_HEALTH
        
class PirateBoat(Boat):
    TURN_SPEED = 10.0  # degrees per timestep
    ACCEL_SPEED = .5 # units of velocity per timestep
    MAX_SPEED = 2.0
    MAX_HEALTH = 100.0
    INITIAL_HEALTH = 90.0
    
    FIRING_SPEED = 10 # Every n turns, they can fire
    CAPACITY = 10 # How much software a boat can hold
    
    def __init__(self, bid=-1, player_id=-1,
                 location=(0.0, 0.0), heading=90.0):
        Boat.__init__(self, bid, player_id, location, heading)

        self.num_cannons = 2
        self.fire_angle = (90, -90)
        self.fire_damage = (20.0, 20.0)
        self.fire_range = (20.0, 20.0)
        self.fire_wait = [0, 0] # If this is zero, that cannon can fire
        # True if the boat wants to fire this turn
        self.firing = [False, False]
        # True if the boat can *actually* fire this turn
        self.fire = [False, False]
        
        # ID of opposing boat that we have requested to board
        self.boarding = -1

        # How many units of cargo we want to load/unload
        self.loading = 0
        self.unloading = 0
        
    def command_fire_left(self):
        """Fires from left side of boat"""
        return self._fire(0)
    def command_fire_right(self):
        """Fires from right side of boat"""
        return self._fire(1)
    def _fire(self, idx):
        """Helper function to regulate firing to only when the boat has finished reloading"""
        if self.fire_wait[idx] <= 0:
            self.fire_wait[idx] = self.FIRING_SPEED
            self.firing[idx] = True
            return True
        else:
            return False
        
    def command_board(self, bid):
        """Board a neighboring boat. Will only succeed if we have collided with that boat,
        it belongs to the other player, and its health is at 0."""
        self.boarding = bid
        return True

    def command_load(self, amount=None):
        """Attempt to load software from a pier (or a neighboring boat?)

        Always returns True, since the boat has no way of knowing whether this command
        will succeed."""

        # We could have Boat.CAPACITY as the default for amount in the function
        # definition, but that would break inheritance.
        if amount is None:
            amount = self.CAPACITY
        self.loading = min(amount, self.CAPACITY - self.software)
        return True

    def command_unload(self, amount=None):
        """Attempt to unload software at a pier, presumably our own."""
        if amount is None:
            amount = self.software
        self.unloading = min(amount, self.software)
        return True

    def reset_state(self):
        Boat.reset_state(self)

        self.boarding = -1
        self.loading = 0
        self.unloading = 0
        for i in range(self.num_cannons):
            self.fire[i] = False
                
    def update(self):
        Boat.update(self)
        
        # Tell the server whether we are firing
        for i in range(self.num_cannons):
            if self.fire_wait[i] > 0:
                self.fire_wait[i] -= 1
            if self.firing[i]:
                print 'Boat %d firing %d' % (self.id, i)
                self.fire[i] = True
                self.firing[i] = False

    def sanity_check(self):
        Boat.sanity_check(self)
        assert self.cargo >= 0 and self.cargo <= self.CAPACITY


class RumRunner(Boat):
    TURN_SPEED = 20.0  # degrees per timestep
    ACCEL_SPEED = .5 # units of velocity per timestep
    MAX_SPEED = 3.0
    MAX_HEALTH = 200.0
    INITIAL_HEALTH = 200.0
    WIDTH = 4
    HEIGHT = 4
    
    TYPE = DOCTORBOAT

    def __init__(self, bid=-1, player_id=-1,
                 location=(0.0, 0.0), heading=90.0):
        Boat.__init__(self, bid, player_id, location, heading)

    def command_heal(self, boat_id):
        if boat_id == self.id: # Doctor, don't heal thyself
            return False

        self.healing = boat_id
        return True

    def reset_state(self):
        Boat.reset_state(self)

        self.healing = -1
        
    def _get_damage_points(self):
        # Doctor can't ram other boats
        return []
    damage_points = property(_get_damage_points)
