#!/bin/sh

while [ 1 -eq 1 ]; do
    timeout 120 python arena.py
    sleep 10
done
