import serverconf as conf
import anydbm as dbm
import time

# TODO: print stats in sorted order (by wins-losses?)
# TODO: use cheetah template engine to nicely render html?
def print_stats():
    players = {}
    db = dbm.open(conf.stats_file, 'r')
    for key in db:
        player, field = key.split('_')
        if player not in players:
            players[player] = {}
        players[player][field] = int(db[key])

    print 'Statistics as of', time.asctime()
    print players
    for name, stats in players.items():
        record = [0,0,0]
        fields = ['wins', 'losses', 'ties']
        for i in range(3):
            try:
                record[i] = stats[fields[i]]
            except KeyError:
                pass # Treat a missing stat as being equal to 0
        format = tuple([name] + record)
        print '%10s -- %2d %2d %2d' % format

if __name__=='__main__':
    print_stats()
