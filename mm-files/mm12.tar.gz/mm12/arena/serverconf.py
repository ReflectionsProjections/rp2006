player_dir = '/local/scratch/jre2/clients'
server_cmd = '/local/scratch/jre2/mm/server.py'
stats_file = 'stats.db'
server_args = ['--remote']
client_args = ['localhost', '1337']
sleep_time = 30

enable_visualizer = True
#visualizer_cmd = '../visualizer.py'
visualizer_args = ['localhost', '1337']
visualizer_cmd = 'viz'
