import os
import time
import sys
import signal
import random
import anydbm as dbm

import serverconf as conf

def run(cmd, args):
    #return subprocess.Popen([cmd] + args) # requires python2.4
    return os.spawnv(os.P_NOWAIT, cmd, [cmd] + args)

def run_match(p1, p2):
    # TODO: if one client does not even connect, server will wait forever
    server = run(conf.server_cmd, conf.server_args)
    time.sleep(2) # give server time to open socket
    if conf.enable_visualizer:
        print 'Launching visualizer'
        viz = run(conf.visualizer_cmd, conf.visualizer_args)
    else:
        viz = -1
    # make sure visualizer connects before game starts
    # also give LCD time to switch display modes if necessary
    time.sleep(5)
    print 'Launching clients'
    p1 = run(os.path.join(conf.player_dir, p1), conf.client_args)
    p2 = run(os.path.join(conf.player_dir, p2), conf.client_args)
    try:
        ret = os.WEXITSTATUS(os.waitpid(server, 0)[1])
        time.sleep(2)
        return ret
    finally:
        for child in viz, p1, p2:
            if child != -1:
                os.kill(child, signal.SIGHUP)

def write_results(db, winner, p1, p2):
    if winner == 0:
        print 'Player 1 wins:', p1
        to_incr = [p1 + '_wins', p2 + '_losses']
    elif winner == 1:
        print 'Player 2 wins:', p2
        to_incr = [p1 + '_losses', p2 + '_wins']
    elif winner == -1:
        print 'Tie game'
        to_incr = [p1 + '_ties', p2 + '_ties']
    for key in to_incr:
        try:
            old_val = int(db[key])
            db[key] = str(old_val+1) # dbm can only hold strings
        except KeyError:
            db[key] = '1'

def run_random_match():
    p1, p2 = random.sample(os.listdir(conf.player_dir), 2)
    result_code = run_match(p1, p2)
    print result_code
    if result_code == 1:
        print 'Uncaught exception: %s vs %vs' % (p1, p2)
        return False
    elif result_code not in (9, 10, 11): # (tie, p1 wins, p2 wins)
        print 'Unknown return code from server:', result_code
        return False
    
    db = dbm.open(conf.stats_file, 'c') # create if not exists
    try:
        write_results(db, result_code - 10, p1, p2)
    finally:
        db.close()
    return True
    
#def main():
    #while run_random_match():
    #    # This is a long-running process, so the current time may be useful
    #    # as a debugging aid.
    #    print 'Game ended at', time.asctime()
    #    print 'Sleeping for %s seconds' % conf.sleep_time
    #    time.sleep(conf.sleep_time)
    
if __name__=='__main__':
    run_random_match()
    #main()
