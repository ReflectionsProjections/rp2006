'''
formats.py - Wire formats for various in-game objects.

The interesting object in this module is "namespace", which is a dictionary
containing instances of Format.
Each instance provides all the information necessary to unserialize objects
of its type.
'''

import game
import player
import boats

#
# Type conversion functions
#
def Bool(s):
    # Replacement for bool builtin, since bool('False') returns True.
    return s.strip() == 'True'

def tuple_of(typ):
    '''Parse the string representation of a tuple, list, or set
    containing the given type and return a tuple.'''
    def convert(data):
        if data[:3] == 'set': # also handle sets
            data = data[3:]
        data = data.strip('()[]')
        if data == '':
            return tuple()
        else:
            return tuple([typ(val) for val in data.split(',')])
    return convert
# convenience name
coord = tuple_of(float) # string -> tuple of floats

def simple_string(s):
    # Remove characters that screw up our message delimiters
    # (we would like to instead use arbitrary strings prefixed with lengths,
    # but the client cannot handle it)
    return s.strip('\n;\x00')

class Format:
    def __init__(self, attrs, cls=dict):
        self.attrs = attrs
        self.cls = cls

_boat_attrs = [
    ('player', int),
    ('id', int),
    ('location', coord),
    ('heading', float),
    ('goal_heading', float),
    ('health', float),
    ('velocity', float), # a scalar: should be 'speed'
    ('collides_with', tuple_of(int))
    ]

# We don't actually use the base class. It would be a boring boat.
#_Boat = Format(cls=boats.Boat, attrs=_boat_attrs)

_PirateBoat = Format(cls=boats.PirateBoat, attrs=_boat_attrs + [
    ('software', float),
    ('fire_angle', tuple_of(int)),
    ('fire_damage', tuple_of(float)),
    ('fire_range', tuple_of(float)),
    ('fire_wait', tuple_of(float)),
    ('fire', tuple_of(Bool))
    #('damage_points', tuple_of(coord)), # no c++ support yet
    ]
)

_RumRunner = Format(cls=boats.RumRunner, attrs=_boat_attrs)

_Game = Format(cls=game.Game, attrs=[
    ('tm', int),
    ('max_tm', int),
    ('status', int),
    ('winner', int)])

_Player = Format(cls=player.Player, attrs=[
    ('id', int),
    ('software', float),
    ('pier', coord),
    ('color', tuple_of(int)),
    ('name', simple_string)
    ])

namespace = dict(PirateBoat=_PirateBoat,
                 RumRunner=_RumRunner,
                 Game=_Game,
                 Player=_Player)
