"""

serial.py - Converts objects to and from a human-readable,
easily-parseable wire format. See formats.py for examples.

"""

LIST = 0
SINGLE = 1

def unserialize(iter, formats, delim=';'):
    kind = int(iter.next())
    if kind == SINGLE:
        return _unserialize_obj(iter.next(), formats, delim)
    else:
        count = int(iter.next())
        return [_unserialize_obj(iter.next(), formats, delim)
                for i in range(count)]

def _unserialize_obj(line, formats, delim=';'):
    try:
        fields = line.split(delim)
        cls_name = fields.pop(0)
    except (ValueError, IndexError): # empty list
        print 'Unserialize received bogus line:',
        print line
        return None
    try:
        format = formats[cls_name]
    except KeyError:
        print 'Unserialize received unexpected type:',
        print cls_name
        return None
    obj = format.cls()
    
    for i, field in enumerate(fields):
        name, constructor = format.attrs[i]
        try:
            setattr(obj, name, constructor(field))
        except IndexError:
            print 'Unserialize received too little data:',
            print format, line
            break
        # This is a necessity for production code;
        # for testing, though, it hides errors.
        #except:
        #    print 'Unserialize received invalid data:',
        #    print format, line
        #    break
    if i < len(fields) - 1:
        print 'Unserialize discarded some extra data:',
        print format, line
    return obj

def serialize_single(obj, formats, delim=';'):
    return '\n'.join([str(SINGLE),
                      _serialize_obj(obj, formats, delim=';')])

def serialize_list(objects, formats, delim=';'):
    serialized_objs = [_serialize_obj(obj, formats, delim)
                       for obj in objects]
    descr = [str(LIST), str(len(objects))] + serialized_objs
    return '\n'.join(descr)

def _serialize_obj(obj, formats, delim=';'):
    cls_name = _class_name(obj)
    attrs = formats[cls_name].attrs
    return delim.join([cls_name] + [str(getattr(obj, attr))
                                    for (attr, discard) in attrs])

def _class_name(obj):
    # Returns the name of an instance's class, removing any
    # any module names preceding it.
    # e.g. instance of boats.Boat -> 'Boat'
    return obj.__class__.__name__.split('.')[-1]
