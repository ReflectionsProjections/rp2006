import random
import time

import boats
import player
import util
from serial import serialize_single, serialize_list, unserialize
import net

class InvalidOrder(Exception):
    pass

class PlayerError(Exception):
    pass

class Order:
    def __init__(self, order_str):
        self.name, args = order_str.split(' ', 1)
        self.args = args.split(';')

def cross(seq_a, seq_b):
    # Note: iter_b must be repeatedly iterable:
    # i.e., it must be an *iterable*, not an *iterator*.
    for a in seq_a:
        for b in seq_b:
            yield a,b

DEBUG = False
def debug(msg):
    print msg

# This (along with "all") will become a built-in in python 2.5
def any(iterable):
    for i in iterable:
        if i:
            return True
    return False

# Does this really belong here? Maybe it should move into net.py.
def unserialize_state(game_state):
    import formats
    
    """Parses the output of game.state() and returns the tuple
    (Game, [players], [boats])
    """

    # This function and serial.unserialize together are
    # so perilously close to requiring no game knowledge at all:
    # i.e., replacing the (game, players, boats) tuple with an
    # Environment class. I get the feeling that doing this would wreak havoc
    # with the C++ half of the code, though.

    lst = game_state.split('\n')
    #print lst
    lines = iter(lst)

    game = unserialize(lines, formats.namespace)
    players = unserialize(lines, formats.namespace)
    boats_lst = unserialize(lines, formats.namespace)

    # Convert boats list to dictionary
    boats = {}
    for b in boats_lst:
        boats[b.id] = b
    
    return game, players, boats

class Game:
    NOT_STARTED = 0
    RUNNING = 1
    DONE = 2

    LENGTH = 20 # how many ticks to run for
    
    # Location of each player's pier (indexed by player ID)
    pier_locs = [(-50,0), (50,0)]
    pier_width = 5
    pier_height = 5
    player_colors = [(255,0,0), (0,128,255)]

    def __init__(self, length=LENGTH, seed=None):
        self.players = []
        self.boats = {} # boat_id -> boat
        self.tm = 0
        self.status = Game.NOT_STARTED
        self.max_tm = length
        self.winner = -1 # No winner yet
        self.num_players = 0
        
        # Seed the RNG (so we can repeat games)
        if seed is None:
            self.random_seed = int(time.time())
        else:
            self.random_seed = seed
        random.seed(seed)

    def add_player(self):
        if self.num_players == 2:
            return -1
        pid = self.num_players
        p = player.Player(id=pid, pier_loc=self.pier_locs[pid],
                          color=self.player_colors[pid])
        self.players.append(p)
        self.num_players += 1
        if self.num_players == 2:
            self.start_game()
        return pid

    def _random_start_loc(self, player_id):
        side = player_id*2 - 1 # -1 or 1
        return (side * random.random() * 40, side * random.random() * 40)
        
    def start_game(self):
        debug('random seed: ' + str(self.random_seed))
        # Scatter some boats randomly.
        for i in range(18):
            b = boats.PirateBoat(player_id=i%2,
                                 location=self._random_start_loc(i%2))
            self.boats[b.id] = b
        for i in range(2):
            b = boats.RumRunner(player_id=i%2,
                                location=self._random_start_loc(i%2))
            self.boats[b.id] = b
        self.status = Game.RUNNING
        
    def next_turn(self, orders):
        if self.status != Game.RUNNING:
            return False

        # Reset boat and player state
        self._pre_orders_check()
        
        # Process orders from players
        for pid, order_lst in orders.items():
            for order_str in order_lst:
                if order_str == '':
                    continue
                try:
                    order = Order(order_str)
                except:
                    debug('Malformed order ' + order_str)
                    continue
                try:
                    if not self._distribute_order(pid, order):
                        print 'Boat or player rejected command:'
                        print order.name, order.args
                except InvalidOrder, e:
                    print 'Rejected order', order.name, order.args
                    print 'Reason:', e
                except PlayerError, e:
                    # Error in boat or player objects
                    print 'Order:', order.name, order.args
                    print str(e)
                    self.end_game((pid+1)%2)
                except Exception, e:
                    # Error in order parsing itself
                    print 'Unknown exception in order handling caused by', pid
                    print str(e)
                    self.end_game((pid+1)%2)

        # Trashtalk
        for player in self.players:
            for line in player.trash_talk:
                print 'Quoth %d: %s' % (player.id, line)

        # Allow boats to process events they can handle themselves
        for b in self.boats.values():
            b.update()

        # Process events that boats cannot handle themselves
        # (e.g. collisions)
        self._post_update_check()

        self.tm += 1
        if self.tm >= self.max_tm:
            if self.players[0].software > self.players[1].software:
                self.end_game(0)
            elif self.players[0].software < self.players[1].software:
                self.end_game(1)
            else:
                self.end_game()
        return True

    def end_game(self, winner=-1):
        self.status = Game.DONE
        self.winner = winner

    def state(self):
        import formats
        
        return '\n'.join([
            serialize_single(self, formats.namespace),
            serialize_list(self.players, formats.namespace),
            serialize_list(self.boats.values(), formats.namespace)])

    def _distribute_order(self, pid, order):
        """Parse orders from the client and deliver them to the
        appropriate object.
        We don't do any game-state-aware validation here."""
        
        # N.B. right now, order.args is entirely strings.
        
        resolv = order.name.split('_')
        if resolv[0] == 'boat':
            # Find appropriate boat object
            try:
                bid = int(order.args[0])
                obj = self.boats[bid]
                # Limitation: Boat objects only accept floats
                args = [float(val) for val in order.args[1:]]
                if obj.player != pid: #you can only give orders to yourself
                    raise InvalidOrder('Attempted to give order '
                                       'to opposing boat')
            except (ValueError, KeyError):
                raise InvalidOrder('Bad boat name')
        elif resolv[0] == 'player':
            obj = self.players[pid]
            # Limitation: Player objects only accept strings
            args = order.args
        
        # Look up and execute function in appropriate object
        cmd = 'command_' + '_'.join(resolv[1:])
        try:
            fn = getattr(obj, cmd)
        except AttributeError:
            raise InvalidOrder('Bad command name: ' + cmd)
        try:
            return fn(*args)
        except TypeError, e: # Wrong number of arguments
            print 'Wrong number of arguments'
            print e
            return False
        except Exception, e:
            print 'Unknown exception caused by player', pid
            print e
            raise PlayerError

    def _pre_orders_check(self):
        for boat in self.boats.values():
            # They have to request again each turn if they are trying to
            # board a boat, fire, load or unload software, or heal.
            # We reset these in _pre_update_check instead of the
            # previous turn's _post_update_check so that the
            # visualizer can see that they happened.
            boat.reset_state()
        for player in self.players:
            player.reset_state()
        
    def _post_update_check(self):
        # Resolve collisions
        for a, b in cross(self.boats.values(), self.boats.values()):
            if a is b:
                continue
            
            # Test if any "damage points" (i.e. the front of the boat)
            # of a have struck b.
            if any([util.pt_collides(pt, b.vertices())
                    for pt in a.damage_points]):
                if a.player == b.player:
                    continue
                #print '%d struck %d' % (a.id, b.id)
                damage = util.magnitude(
                    util.sub(a.velocity_vector(), b.velocity_vector()))
                # Normalize to be from 0 to 1
                damage /= a.MAX_SPEED + b.MAX_SPEED
                # TODO: attenuate the damage based on the impact angle?
                # We could also stop one or both boats.
                # Also maybe prevent boats from striking multiple times
                # in the same collision.

                # Do no more than 15% damage
                b.health -= (b.MAX_HEALTH*.15*damage)
                b.health = max(0, b.health) # sanity check
            
            # Test if the boats overlap at all,
            # regardless of damage points
            if util.collides(a.vertices(), b.vertices()):
                #print '%d and %d overlap' % (a.id, b.id)
                a.collides_with.add(b.id)
                b.collides_with.add(a.id)

        for boat in self.boats.itervalues():
            if isinstance(boat, boats.PirateBoat):
                # Allow boats to be boarded
                if boat.boarding != -1:
                    #print '%d wants to board %d' % (boat.id, boat.boarding)
                    try:
                        other = self.boats[boat.boarding]
                    except KeyError:
                        continue
                    if boat.boarding in boat.collides_with \
                           and other.health < other.MAX_HEALTH*0.1 \
                           and boat.player != other.player \
                           and not isinstance(other, boats.RumRunner):
                        #print '%d succeeds boarding %d ' % (boat.id, boat.boarding)
                        other.player = boat.player
                        other.health = other.MAX_HEALTH / 2

                for i in range(boat.num_cannons):
                    if boat.fire[i]:
                        self._fire(boat, i)

                if boat.loading > 0:
                    self._try_transfer(boat, boat.loading, 1)
                if boat.unloading > 0:
                    #print '%d wants to unload %d' %(boat.id, boat.unloading)
                    self._try_transfer(boat, boat.unloading, -1)

            elif isinstance(boat, boats.RumRunner):
                if boat.healing != -1:
                    #print '%d wants to heal %d' % (boat.id, boat.healing)
                    try:
                        other = self.boats[boat.healing]
                    except KeyError:
                        continue
                    if isinstance(other, boats.RumRunner) or boat.healing not in boat.collides_with:
                        continue
                    #print '%d succeeds in healing %d' % (boat.id, boat.healing)                    
                    other.health = min(other.MAX_HEALTH,
                                       other.health + other.MAX_HEALTH/10)
                    
        
    def _fire(self, boat, cannon):
        angle = (boat.heading+boat.fire_angle[cannon])%360
        debug('%d fired at angle %f' % (boat.id, angle))
        # Oh, would that we had dictionary comprehensions.
        rects = {}
        for b in self.boats.itervalues():
            if b is not boat:
                rects[b.id] = b.vertices()
        hit = util.cast_ray(boat.location, angle,
                            boat.fire_range[cannon], rects)
        if hit is not None:
            other = self.boats[hit]
            debug('%d hit %d' % (boat.id, hit))
            other.health = max(other.health - boat.fire_damage[cannon], 0)

    def _try_transfer(self, boat, amount, direction):
        # For now, you can only load from a pier
        who = None
        for player in self.players:
            if util.collides(boat.vertices(),
                             util.rect(player.pier,
                                       self.pier_width,
                                       self.pier_height)):
                who = player
                break
        if who is not None:
            if direction == 1:
                transfer = min(amount, who.software)
            else:
                transfer = amount
            who.software -= transfer*direction
            boat.software += transfer*direction
        
