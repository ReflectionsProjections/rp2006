import sys
import player
import game

player_names = sys.argv[1:]
if len(player_names) != 2:
    print 'Usage: python test.py player1 player2'
    sys.exit()
g = game.Game(10)
p0_id = g.add_player()
p0 = getattr(player, player_names[0])(p0_id)
p1_id = g.add_player()
p1 = getattr(player, player_names[1])(p1_id)

while g.status != g.DONE:
    print 'TURN', g.tm
    # This is of course not necessary: we could just use the game object
    # directly without serializing/unserializing. But it's best to make sure
    # that serialization works.
    gm, players, boats = game.unserialize_state(g.state())
    
    print 'Score: %f to %f' % (players[0].software, players[1].software)
    for b in boats.values():
        print b
    
    orders = {}
    orders[p0_id] = p0.give_orders(gm, players, boats)
    orders[p1_id] = p1.give_orders(gm, players, boats)
    
    g.next_turn(orders)

print 'Game completed.'
if g.winner == -1:
    print 'Tie game!'
else:
    print 'Winner: Player', g.winner
