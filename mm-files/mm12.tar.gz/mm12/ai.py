import random
import math
import time

import game
import boats as boats_ # oops. I used "boats" as a name too many times.
import util

class AIPlayer:
    """
    The basic class definition of an AI player.  This class should be subclassed
    for all custom AI players. This class is not updated with its in-game state
    (software, etc.) -- it is ENTIRELY maintained by the AI, i.e. by itself.
    """

    def __init__(self, id):
        self.id = id # My player id
        
    def give_orders(self, state, players, boats):
        """
        Return a newline-delimited list of orders for this player
        in the form:
        command_name arg1;arg2;...
        
        These commands will be executed for the player on the next
        turn.

        Accepts the arguments:
         state - Game object.
         players - list of Player objects, one being the player and one being the enemy.
         boats - dictionary of boat_id->Boat for all boats in the game
        """
        return '\n'.join([])

class SlowPlayer(AIPlayer):
    def __init__(self, id):
        AIPlayer.__init__(self, id)
        self.first_time = True

    def give_orders(self, state, players, boats):
        time.sleep(random.random()*.55)
        return []

class TestPlayer(AIPlayer):
    def __init__(self, id):
        AIPlayer.__init__(self, id)
        self.first_time = True
    
    def give_orders(self, state, players, boats):
        me = players[self.id]
        enemy = players[(self.id+1)%2]
        
        if self.first_time:
            self.first_time = False
            return self._initial_orders(state, boats, me, enemy)
        else:
            return self._orders(state, boats, me, enemy)


    def _initial_orders(self, state, boats, me, enemy):
        orders = []
        for boat in boats.values():
            if boat.player == me.id:
                orders.append('boat_velocity %d;%f' % (
                    boat.id, boat.MAX_SPEED/10))
                orders.append('boat_turn_absolute %d;%f' % (
                    boat.id, util.angle_between(boat.location,
                                                enemy.pier)))
        return orders

    def _orders(self, state, boats, me, enemy):
        orders = []
        for boat in boats.values():
            if boat.player != me.id or isinstance(boat, boats_.RumRunner):
                continue
            print repr(boat)
            # This should probably be abstracted
            # (into, e.g., boat.can_fire_left())
            if boat.fire_wait[0] == 0:
                orders.append('boat_fire_left ' + str(boat.id))
            if boat.fire_wait[1] == 0:
                orders.append('boat_fire_right ' + str(boat.id))
        return orders

        
class BasicPlayer(AIPlayer):
    def __init__(self, id):
        AIPlayer.__init__(self, id)
        self.openEngagements = {}    # Our boat => boat being engaged (- for pier)
        self.first_turn = True
    
    
    def give_orders(self, state, players, boats):
        orders = []
        print self.openEngagements
        
        #
        # We want to deliver orders per each active boat that is ours.
        #
        for boat in boats.values():
            if boat.player != self.id:
                continue
                
            print 'BASIC BOAT ' + str(boat.id)
            
            if self.first_turn:
                orders.append('boat_velocity ' + str(boat.id) + ';2')
            newOrders = self.ordersForBoat(boat, state, players, boats)
            orders.extend(newOrders)

        if self.first_turn:
            self.first_turn = False
        
        return orders
        
        
    def ordersForBoat(self, thisBoat, state, players, boats):
        """
        The boat given should be this player's boat.  Given that,
        the game state is reviewed and orders are assigned to the boat
        according to the following rules:
        
        1. If any enemy boats remain, they are eliminated before
            attempting to reach the pier.
        2. This boat will attack the boat that is closest to it.
        
        The tactic followed by the boat will be to fire on one side, and
        then turn towards the enemy boat and reveal its other side to fire
        there.  It will repeat this until either the enemy boat is too 
        close (in which case it will turn away instead), or the enemy
        boat no longer exists.
        
        The orders for the given boat (if any), are returned.
        """
        print "GETTING NEW ORDERS!"
        orders = []        # We will be returning this
        
        #
        # If this boat has open engagements, follow them.  Else, create a new
        # engagement for this ship.
        #
        if self.openEngagements.has_key(thisBoat.id):
            print "BOAT " + str(thisBoat.id) + " HAS ENGAGEMENT"
            
            # Get a reference to the boat we are engaging
            otherBoat = boats[self.openEngagements[thisBoat.id]]
            
            #
            # If the other boat is dead, move along.  Otherwise, 
            # see where we are.
            #
            if otherBoat.health == 0:
                print "OTHER BOAT DESTROYED!"
                del self.openEngagements[thisBoat]
            else:
                # This is the direction of the other boat.
                enemy_angle = util.angle_between(thisBoat.location, otherBoat.location)
                
                #
                # If we're not yet in position, make small corrections.
                #
                if abs(thisBoat.goal_heading - thisBoat.heading) > 15:
                    print "NOT IN POSITION!!!"
                    print thisBoat.goal_heading
                    print thisBoat.heading
                    try_plus = abs(thisBoat.goal_heading + ((enemy_angle + 90) % 360))
                    try_minus = abs(thisBoat.goal_heading - ((enemy_angle - 90) % 360))
                    
                    # Make a small adjustment to correct for the other boat's position.
                    if try_plus < try_minus:
                        orders.append('boat_turn_absolute ' + str(thisBoat.id) + ';'
                            + str((enemy_angle + 90) % 360))
                    else:
                        orders.append('boat_turn_absolute ' + str(thisBoat.id) + ';'
                            + str((enemy_angle - 90) % 360))
                
                #
                # If we are in position, FIRE and turn ~180 degrees
                #
                else:
                    print "IN POSITION!!!!"
                    # Figure out which side we're to fire from.
                    isLeft = None
                    if abs((enemy_angle + 90) - thisBoat.goal_heading) < 10:
                        isLeft = True
                    elif abs((enemy_angle - 90) - thisBoat.goal_heading) < 10:
                        isLeft = False
                    
                    #
                    # Fire on the side we have
                    #
                    if isLeft == True and thisBoat.fire_wait[0] == 0:
                        orders.append('boat_fire_left ' + str(thisBoat.id) + '\n')
                        orders.append('boat_turn_absolute ' + str(thisBoat.id) + ';'
                            + str((thisBoat.goal_heading + 180) % 360))
                        print 'FIRE LEFT!!!!!!'
                        return orders
                    
                    elif thisBoat.fire_wait[1] == 0:
                        orders.append('boat_fire_right ' + str(thisBoat.id))
                        orders.append('boat_turn_absolute ' + str(thisBoat.id) + ';' 
                            + str((thisBoat.goal_heading + 180) % 360))
                        print 'FIRE RIGHT!!!!!!'
                        return orders
                


        #
        # Test for open engagement again, in case one was resolved
        #
        if not self.openEngagements.has_key(thisBoat.id):
            closestDist = None
            closestBoat = None
            
            # Find the closest boat to us
            for otherBoat in boats.values():
                if otherBoat.player == self.id:
                    continue
                
                dist = util.distance(thisBoat.location, otherBoat.location)
                
                if closestBoat == None or dist < closestDist:
                    closestDist = dist
                    closestBoat = otherBoat
            
            print "CREATING ENGAGEMENT WITH " + str(closestBoat.id)
            self.openEngagements[thisBoat.id] = closestBoat.id
            print self.openEngagements;
            enemy_angle = util.angle_between(thisBoat.location, closestBoat.location)
            if (abs(thisBoat.heading - enemy_angle + 90) < 
                    abs(thisBoat.heading - enemy_angle - 90)):
                target_angle = enemy_angle + 90 % 360
            else:
                target_angle = enemy_angle - 90 % 360
                
            orders.append('boat_turn_absolute ' + str(thisBoat.id) + ';' + str(target_angle))
            
        return orders

class PierPlayer(AIPlayer):
    """
    Attempts to drive all boats towards the enemy pier with reckless abandon,
    load them, and drive them back. Will work well as long as nobody is shooting at us
    and our boats don't all arrive at the pier at the same time... hmm.
    """
    def __init__(self, id):
        AIPlayer.__init__(self, id)
        self.first_time = True
    
    def give_orders(self, state, players, boats):
        me = players[self.id]
        enemy = players[(self.id+1)%2]
        
        orders = []
        if self.first_time:
            self.first_time = False
            orders += self._initial_orders(state, boats, me, enemy)
        orders += self._orders(state, boats, me, enemy)
        return orders

    def _initial_orders(self, state, boats, me, enemy):
        orders = ['boat_velocity %d;%f' % (boat.id, boat.MAX_SPEED)
                for boat in boats.values() if boat.player == me.id]
        orders.append('player_name PierPlayer')
        return orders

    def _orders(self, state, boats, me, enemy):
        orders = []
        for boat in boats.values():
            if boat.player != me.id:
                continue
            if boat.software > 0:
                if util.pt_collides(me.pier, boat.vertices()):
                    orders.append('boat_unload ' + str(boat.id))
                else:
                    orders.append('boat_turn_absolute %d;%f' % (
                        boat.id, util.angle_between(boat.location, me.pier)))
            else:
                if util.pt_collides(enemy.pier, boat.vertices()):
                    orders.append('boat_load ' + str(boat.id))
                else:
                    orders.append('boat_turn_absolute %d;%f' % (
                        boat.id, util.angle_between(boat.location, enemy.pier)))
        return orders

class BusyPlayer(AIPlayer):
    def __init__(self, id):
        AIPlayer.__init__(self, id)
        self.first_time = True

    # Most of this should probably be rolled into AIPlayer.
    def give_orders(self, state, players, boats):
        print 'PLAYER', self.id
        # Set internal state
        self.game = state
        self.me = players[self.id]
        self.enemy = players[(self.id+1)%2]
        self.my_boats = {}
        self.enemy_boats = {}
        for id, boat in boats.items():
            if boat.player == self.me.id:
                self.my_boats[id] = boat
            else:
                self.enemy_boats[id] = boat
        self.orders = []
        
        #if self.first_time:
        #    self.first_time = False
        #    self._do_initial_orders()
        self._do_orders()
        
        return self.orders

    def _order(self, cmd, *args):
        self.orders.append(cmd % args)
        
    #def _do_initial_orders(self):
    #    for boat in self.my_boats.values():
    #        self._order('boat_velocity %d;%f', boat.id, boat.MAX_SPEED)

    def _do_orders(self):
        for i, boat in enumerate(self.my_boats.values()):
            # Just in case it got stopped for any reason
            self._order('boat_velocity %d;%f', boat.id, boat.MAX_SPEED)

            if isinstance(boat, boats_.PirateBoat):
                if i%2 == 0:
                    self._pier_run(boat)
                else:
                    self._find_target(boat)
            elif isinstance(boat, boats_.RumRunner):
                # TODO: move somewhere :-p
                self._heal_something(boat)

    def _pier_run(self, boat):
        if boat.software > 0:
            if util.pt_collides(self.me.pier, boat.vertices()):
                self._order('boat_unload %d', boat.id)
            else:
                self._order('boat_turn_absolute %d;%f', boat.id,
                            util.angle_between(boat.location,
                                               self.me.pier))
        else:
            if util.pt_collides(self.enemy.pier, boat.vertices()):
                self._order('boat_load %d', boat.id)
            else:
                self._order('boat_turn_absolute %d;%f', boat.id,
                            util.angle_between(boat.location,
                                               self.enemy.pier))

    def _attack_points(self, boat):
        '''
        Choose what points to try to reach to best attack a boat.
        In general, the idea is either be in front or behind it.
        '''
        angle = math.radians(boat.heading)
        vect = (math.cos(angle), math.sin(angle))
        if boat.velocity == 0:
            offsets = (util.scale(vect, 10), util.scale(vect, -10))
        else:
            offsets = (util.scale(vect, 20), (0,0))
        return [(boat.id, util.add(boat.location, offsets[0])),
                (boat.id, util.add(boat.location, offsets[1]))]
    
    def _find_target(self, boat):
        # This would need redoing to handle anything other than
        # two cannons, one on each side, each with the same range
        attack_points = []
        rng = boat.fire_range[0]
        for other in self.enemy_boats.values():
            attack_points += self._attack_points(other)
        
        # TODO: filter based on which side we can fire from
        #if boat.fire_wait[0] > 6:
        #    attack_points = filter(, attack_points)

        # Does not work in python 2.3
        #attack_points.sort(
        #    key=lambda tup: util.distance(tup[1],boat.location))
        attack_points.sort(lambda x, y: cmp(
            util.distance(x[1],boat.location),
            util.distance(y[1],boat.location)))
        try:
            target_id, target_pt = attack_points[0]
        except: # there are no enemy boats!
            self._pier_run(boat)
            return
        print '%d chooses %d' % (boat.id, target_id)
        target = self.enemy_boats[target_id]
        if target.health < 0.1*target.MAX_HEALTH:
            print '%d wants to capture %d' % (boat.id, target.id)
            self._capture(boat, target)
        elif util.distance(boat.location, target.location) < rng:
            print '%d wants to attack %d' % (boat.id, target.id)
            self._attack(boat, target)
        else:
            print '%d wants to intercept %d' % (boat.id, target.id)
            self._move_to(boat, target_pt)

    def _capture(self, boat, target):
        # TODO: we should avoid the pointy parts of the boat
        # we are trying to capture
        if target.id not in boat.collides_with:
            self._move_to(boat, target.location)
        else:
            print '%d trying to capture %d' % (boat.id, target.id)
            self._order('boat_board %d;%d', boat.id, target.id)

    def _attack(self, boat, target):
        theta = util.angle_between(boat.location, target.location)
        theta_l = (boat.heading + 90)%360
        theta_r = (boat.heading - 90)%360
        diff_l = abs(theta - theta_l)
        diff_r = abs(theta - theta_r)
        # Threshold ranges from 10 to 45, depending on what side
        # of the opponent's boat we are on
        # TODO: take distance into account, as well
        diff = (boat.heading - target.heading)%180
        threshold = 10 + abs(90 - diff)/5
        print 'threshold', threshold
        print 'heading %f, right %f, left %f, angle_between %f' % (
            boat.heading, theta_r, theta_l, theta)
        if diff_l < diff_r: # goal is to fire left
            if diff_l < threshold: # can fire
                print 'fire left!'
                self._order('boat_fire_left %d', boat.id)
            else: # adjust position
                print 'adjust left'
                self._order('boat_turn_absolute %d;%f', boat.id,
                            (theta - 90)%360)
        else: # fire right
            if diff_r < threshold:
                print 'fire right!'
                self._order('boat_fire_right %d', boat.id)
            else:
                print 'adjust right'
                self._order('boat_turn_absolute %d;%f', boat.id,
                            (theta + 90)%360)

    def _move_to(self, boat, pt):
        self._order('boat_turn_absolute %d;%f', boat.id,
                    util.angle_between(boat.location, pt))

    def _heal_something(self, boat):
        if len(boat.collides_with) > 0:
            choices = [self.my_boats[b] for b in boat.collides_with
                       if b in self.my_boats]
            choices.sort(lambda a,b: cmp(a.health, b.health))
            if len(choices) > 0:
                self._order('boat_heal %d;%d' % (boat.id, choices[-1].id))

class RamPlayer(AIPlayer):
    def __init__(self, id):
        AIPlayer.__init__(self, id)
        self.first_time = True
        self.wait_counter = {}
    
    def give_orders(self, state, players, boats):
        print 'PLAYER', self.id
        
        # Set internal state
        self.game = state
        self.me = players[self.id]
        self.enemy = players[(self.id+1)%2]
        self.my_boats = {}
        self.enemy_boats = {}
        for id, boat in boats.items():
            if boat.player == self.me.id:
                self.my_boats[id] = boat
            else:
                self.enemy_boats[id] = boat
        self.orders = []

        # Redo our assignments every turn because distances
        # may have changed
        self.assignments = {}
        
        self._do_orders()
        
        return self.orders

    def _order(self, cmd, *args):
        self.orders.append(cmd % args)
        
    def _do_orders(self):
        for i, boat in enumerate(self.my_boats.values()):
            #if i%2 == 0:
            #    self._pier_run(boat)
            #else:
            self._find_target(boat)

    def _pier_run(self, boat):
        self._order('boat_velocity %d;%f', boat.id, boat.MAX_SPEED)
        if boat.software > 0:
            if util.pt_collides(self.me.pier, boat.vertices()):
                self._order('boat_unload %d', boat.id)
            else:
                self._order('boat_turn_absolute %d;%f', boat.id,
                            util.angle_between(boat.location,
                                               self.me.pier))
        else:
            if util.pt_collides(self.enemy.pier, boat.vertices()):
                self._order('boat_load %d', boat.id)
            else:
                self._order('boat_turn_absolute %d;%f', boat.id,
                            util.angle_between(boat.location,
                                               self.enemy.pier))
        
    def _find_target(self, boat):
        if boat in self.assignments:
            target = self.assignments[boat]
        else:
            # Find closest boat not already being attacked
            targets = self.enemy_boats.keys()
            for enemy in self.assignments.values():
                targets.remove(enemy.id)
            # Does not work in python 2.3
            #targets.sort(key=lambda b: util.distance(
            #    self.enemy_boats[b].location, boat.location))
            targets.sort(lambda b1, b2: cmp(
                util.distance(self.enemy_boats[b1].location, boat.location),
                util.distance(self.enemy_boats[b2].location, boat.location)))
            if len(targets) == 0:
                self._pier_run(boat)
                return
            target = self.enemy_boats[targets[0]]
            self.assignments[boat.id] = target
        
        self._order('boat_velocity %d;%f', boat.id, boat.MAX_SPEED)

        # Did we already collide? then wait for timer to expire.
        if boat.id in self.wait_counter:
            self.wait_counter[boat.id] -= 1
            if self.wait_counter[boat.id] == 0:
                del self.wait_counter[boat.id]
            return
        
        if target.id in boat.collides_with:
            # Either capture or swing around for another pass
            if target.health < .10*target.MAX_HEALTH:
                self._order('boat_board %d;%d', boat.id, target.id)
            else: # set timer and swing wide
                self.wait_counter[boat.id] = 2
                self._order('boat_turn_absolute %d;%f', boat.id,
                            (target.heading + 90)%360)
        else:
            self._order(
                'boat_turn_absolute %d;%f', boat.id,
                util.angle_between(boat.location, target.location))

    # Attack a boat only if we can do so without moving.
    # Copied, with modifications, from _attack in BusyPlayer
    def _try_attack(self, boat, target):
        theta = util.angle_between(boat.location, target.location)
        theta_l = (boat.heading + 90)%360
        theta_r = (boat.heading - 90)%360
        diff_l = abs(theta - theta_l)
        diff_r = abs(theta - theta_r)
        # Threshold ranges from 10 to 45, depending on what side
        # of the opponent's boat we are on
        # TODO: take distance into account, as well
        diff = (boat.heading - target.heading)%180
        threshold = 10 + abs(90 - diff)/5
        print 'threshold', threshold
        print 'heading %f, right %f, left %f, angle_between %f' % (
            boat.heading, theta_r, theta_l, theta)
        if diff_l < threshold:
            print 'fire left!'
            self._order('boat_fire_left %d', boat.id)
        elif diff_r < threshold:
            print 'fire right!'
            self._order('boat_fire_right %d', boat.id)
