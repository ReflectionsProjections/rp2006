#include "Client.h"

using namespace std;

void Client::updateState(const State &s) {
	// Set me and enemy pointers
	players.clear();
	for (std::vector<Player*>::const_iterator i = s.players.begin();
		 i != s.players.end(); i++) {
		players.push_back(*i);
		if ((*i)->id == playerNumber)
			me = *i;
		else
			enemy = *i;
	}

	// Distribute boats appropriately
	allBoats.clear();
	myBoats.clear();
	enemyBoats.clear();
	allPBoats.clear();
	myPBoats.clear();
	enemyPBoats.clear();
	myRumRunner = NULL;
	enemyRumRunner = NULL;
	for (std::vector<Boat*>::const_iterator i = s.boats.begin();
		 i != s.boats.end(); i++) {
		Boat* b = *i;
		
		allBoats.push_back(b);
		if (b->player == playerNumber)
			myBoats.push_back(b);
		else
			enemyBoats.push_back(b);
		
		if (PirateBoat* pb = dynamic_cast<PirateBoat*>(b)) {
			allPBoats.push_back(pb);
			if (pb->player == playerNumber)
				myPBoats.push_back(pb);
			else
				enemyPBoats.push_back(pb);
		}
		else if (RumRunner* rr = dynamic_cast<RumRunner*>(b)) {
			if (rr->player == playerNumber)
				myRumRunner = rr;
			else
				enemyRumRunner = rr;
		}
	}

	game = s.game;
}
