#include <Ogre.h>
#include <OgreSingleton.h>
using namespace std;
using namespace Ogre;

class TextRenderer : public Ogre::Singleton<TextRenderer> {
private:
   Ogre::OverlayManager*    _overlayMgr;
   Ogre::Overlay*           _overlay;
   Ogre::OverlayContainer*  _panel;
public:
   TextRenderer();
   ~TextRenderer();
   // create a new unique textbox
   void addTextBox(const string& ID,const string& text,Real x,Real y,Real width,Real height,const ColourValue& color = ColourValue(1.0, 1.0, 1.0, 1.0));
   // change text box given by id string to Text
   void setText(const string& ID, const string& Text);
   // remove text box given by id string
   void removeTextBox(const string& ID);
};
