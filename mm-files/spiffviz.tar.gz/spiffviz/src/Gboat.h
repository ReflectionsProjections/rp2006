#include "Model.h"
#include "MovableText.h"
#include "Ogre.h"
#include "Model.h"

using namespace Ogre;

class Gboat {
   public:
      Gboat(SceneManager* sceneMgr, Boat* boat, std::vector<Player *> players );
      void update(Boat* boat);
      int player, id, keepAlive;
   protected:
      double mHeading;
      bool mOnFire;
      bool mGeneratedSail;
      SceneManager* mSceneMgr;
      SceneNode* mNode;
      SceneNode* mFireNode;
      Entity* mEnt;
};
