#include "Gboat.h"
#include <iostream>

//FIXME: there are all sorts of limitations on number of boats, materials,
//textures, etc and they won't be fixed.  thankfully, they probably won't occur,
//but if they do, viz will throw and exception and die hard
/*   // add text
     name[0] = 't';
     MovableText* msg = new MovableText(name, "This is a boat", "BlueHighway", 2, ColourValue::Red);
     msg->setTextAlignment(MovableText::H_CENTER, MovableText::V_ABOVE);
     msg->setAdditionalHeight( 10.0f );
     mNode->attachObject(msg);
     */
/* name schema:
 * char name[3] where name[0] is:
 * 'b' for boat
 * 's' for smoke
 * 't' for texture
 * 'm' for material
 * name[1] is id of player/boat
 * name[2] is 0
 */
void createSailTexture(char* name, int r1, int g1, int b1, int r2, int g2, int b2) {
   TexturePtr texture = TextureManager::getSingleton().createManual(name, ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, TEX_TYPE_2D, 256, 256, 0, PF_BYTE_BGRA);
   HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();
   pixelBuffer->lock(HardwareBuffer::HBL_NORMAL); // for best performance use HBL_DISCARD!
   const PixelBox& pixelBox = pixelBuffer->getCurrentLock();
   uint8* pDest = static_cast<uint8*>(pixelBox.data);
   // This is where some cool procedural generation algorithm would go...
   for (size_t j = 0; j < 256; j++) {
      for(size_t i = 0; i < 256; i++) {
         *pDest++ = b1; // B
         *pDest++ = g1; // G
         *pDest++ = r1; // R
         *pDest++ = 0; // A
      }
   }
   pixelBuffer->unlock();
}
void changeSailTexture( std::vector<Player *> players, int pid, Entity* ent ) {
   static bool alreadyGenerated = false;
   static int matCount = 0;
   char tname[3]; tname[0] = 't'; tname[1] = pid; tname[2] = 0;
   char mname[3]; mname[0] = 'm'; mname[1] = matCount; mname[2] = 0;
   std::cout << "Creating Texture with tname= " << tname << " and mname= " << mname << std::endl;
   if (!alreadyGenerated) {
      tname[1] = 0;
      createSailTexture(tname, 255, 0, 0, 255, 0, 0);
      tname[1] = 1;
      createSailTexture(tname, 0, 0, 255, 0, 0, 255);
      alreadyGenerated = true;
   }
   // Replace sail materials with the one we generated
   std::cout << "replacing materials\n";
   tname[1] = pid;
   for (unsigned int i = 0; i < ent->getNumSubEntities(); i++) {
      if (i > 24 && i < 35) {
         mname[1] = matCount++;
         std::cout << "Assigning Texture with tname= " << tname << " and mname= " << mname << std::endl;
         MaterialPtr mat = ent->getSubEntity(i)->getMaterial()->clone(mname);
         mat->getTechnique(0)->getPass(0)->getTextureUnitState(0)->setTextureName(tname);
         ent->getSubEntity(i)->setMaterialName(mname);
      }
   }
}
Gboat::Gboat(SceneManager* sceneMgr, Boat* boat, std::vector<Player *> players ) {
   std::cout << "@@@ MM @@@ creating boat\n";
   mSceneMgr = sceneMgr;
   mOnFire = false;
   mGeneratedSail = false;
   char name[3]; name[0] = 'b'; name[1] = boat->id+1; name[2] = 0;
   // create entity
   mEnt = mSceneMgr->createEntity(name, "galleon.mesh");
   changeSailTexture( players, boat->player, mEnt );
   // attach to scene
   mNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
   mNode->attachObject(mEnt);
   mNode->setScale( 7.0f, 7.0f, 7.0f );
   // update boat data
   update(boat);
}
void Gboat::update(Boat* boat) {
   std::cout << "@@@ MM @@@ updating boat\n";
   // set position / heading
   mNode->setPosition(boat->location.x*10,15.0,boat->location.y*10);
//   mNode->setOrientation( Quaternion(Radian(boat->heading), Vector3::UNIT_Y) ); //FIXME: this, or the one below?
   mNode->setOrientation( Quaternion(Radian(Degree(boat->heading)), Vector3::UNIT_Y) );
   if (boat->health < 50 && !mOnFire) { // add smoke/fire when heavily damaged
      mOnFire = true;
      char name[3]; name[0] = 's'; name[1] = boat->id+1; name[2] = 0;
      mFireNode = mNode->createChildSceneNode(Vector3(0,-5,0));
      ParticleSystem* mSmoke = mSceneMgr->createParticleSystem(name,"Examples/Smoke");
      mFireNode->attachObject(mSmoke);
      mFireNode->setScale(0.3f,0.3f,0.3f); //FIXME: this doesn't reduce size of smoke properly
      mFireNode->setVisible(true);
   }
   if (boat->health > 50 && mOnFire) {
      mFireNode->setVisible(false);
      mOnFire = true;
   }
}
