#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "TCPConnectTo.h"

int connectTo(std::string serverHost, int port)
{
	// Open a socket.
	int fd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	struct sockaddr_in sa;
	// Find the server host to connect to.
	hostent *he = gethostbyname(serverHost.c_str());
	if (he == NULL)
		throw TCPConnectException();
	// Set the server host and port.
	sa.sin_family = AF_INET;
	memcpy(&sa.sin_addr, he->h_addr, he->h_length);
	sa.sin_port = htons(port);
	// Try to connect.
	if (connect(fd, (const sockaddr *) &sa, sizeof(sockaddr_in)) != 0)
		throw TCPConnectException();
	// Finally, we are connected!
	return fd;
}

void writeToSock(std::string str, int fd) {
	char lenBuf[11];
	sprintf(lenBuf, "%10d", str.size());
	write(fd, lenBuf, 10);
	write(fd, str.c_str(), str.size());
	fsync(fd);
}
