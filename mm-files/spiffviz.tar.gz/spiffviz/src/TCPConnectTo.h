#ifndef	__TCP_CONNECT_TO__H__
#define	__TCP_CONNECT_TO__H__

#include <string>

class TCPConnectException { };

int connectTo(std::string serverHost, int port);
void writeToSock(std::string str, int fd);

#endif	// __TCP_CONNECT_TO__H__
