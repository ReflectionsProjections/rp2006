#ifndef	__MESSAGE_PARSING__H__
#define	__MESSAGE_PARSING__H__

#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>
#include <iostream>

// for Coord
#include "Model.h"

class Packet;
class Line;
class Item;

class ReadException         { };
class InvalidItemException  { };
class WrongTypeException    { };
class StateMessageException { };

class Packet {
private:
	int len;
	char *data;
	friend class Line;
	friend class Item;
public:
	Packet(int fd, int maxSize = 65536) : len(0), data(NULL)
	{
		// Read the data length.
		char lenStr[11];
		int rl = read(fd, lenStr, 10);
		lenStr[rl] = 0;
		long lenInt = strtol(lenStr, NULL, 10);
		if ((lenInt <= 0) || (lenInt > maxSize))
			throw ReadException();

		// Allocate data buffer and read data.
		data = new char[lenInt+1];
		len = 0;
		int x = 0;
		while ((len < lenInt)&&(x != -1)) {
			x = read(fd, data+len, lenInt-len);
			if (x >= 0)
				len += x;
		}
		if (x == -1) {
			delete [] data;
			len = 0;
			data = NULL;
			throw ReadException();
		} else {
			data[len] = 0;
			//std::cout << "*** PACKET ***" << std::endl << data << std::endl;
		}
	}
	~Packet()
	{
		if (data != NULL) {
			delete [] data;
			data = NULL;
		}
	}
};

class Line {
private:
	const char *line;
	friend class Item;
public:
	Line(const Packet &pkt) : line(pkt.data) { }
	// Go to the next line.
	void operator++()
	{
		if (!line) return;
	
		while ((*line != 0) && (*line != '\n'))
			line++;
	
		if (*line == 0)
			line = 0; // no more lines.
		else	line++;
	}
	void operator++(int)
	{ operator++(); }
};

class Item {
private:
	int len;
	const char *data;

	Item(int len, const char *data) : len(len), data(data) { }

	static int itemLength(const char *x)
	{
		int len = 0;
		while ((*x != 0) && (*x != '\n') && (*x != ';')) {
			x++;
			len++;
		}
		return len;
	}
public:
	Item() : len(0), data(0) { }
	Item(Line ln) : len(itemLength(ln.line)), data(ln.line) { }
	Item(const Packet &pkt) : len(pkt.len), data(pkt.data) { }

	// Go to the next item on this line.
	void operator++()
	{
		if (!data) throw InvalidItemException();
	
		if ((data[len] == 0) || (data[len] == '\n')) {
			// no more items.
			len = 0;
			data = 0;
		} else {
			data = data+len+1;
			len = itemLength(data);
		}
	}
	void operator++(int)
	{ operator++(); }

	// Make an item that is a subrange of this item.
	Item sub(int start, int length) const
	{
		if (!data) throw InvalidItemException();
	
		if (start <= 0) {
			start = 0;
		} else if (start > len) {
			start = len;
		}
		if (start+length > len) {
			length = len-start;
		} else if (length < 0) {
			length = len-start+length+1;
			if (length < 0)
				length = 0;
		}
		return Item(length, data+start);
	}

	// Check whether this item contains the expected string.
	bool isString(const char *expected)
	{
		if (!data) throw InvalidItemException();
	
		return
		((int) strlen(expected) == len) &&
		(strncmp(expected, data, len) == 0);
	}

	// Read various scalar data types.	
	int readInt()
	{
		if (!data) throw InvalidItemException();
	
		char *endptr;
		int i = strtol(data, &endptr, 10);
		if (endptr > data+len)
			throw WrongTypeException();
		else	return i;
	}
	
	double readFloat()
	{
		if (!data) throw InvalidItemException();
	
		char *endptr;
		double d = strtod(data, &endptr);
		if (endptr > data+len)
			throw WrongTypeException();
		else	return d;
	}
	
	bool readBool()
	{
		if (!data) throw InvalidItemException();
	
		if (isString("True"))
			return true;
		else if (isString("False"))
			return false;
		else
			throw WrongTypeException();
	}

	std::string readStr()
	{
		// data might end with null at len+1, but it also might have
		// ; or \n. So just append our own null.
		//char *dataCopy = new char[len+1];
		std::string s(data, len);
		s += '\0';
		return s;
	}

private:
	// is there a better way to do this?
	void readScalar(int *i)
	{ *i = readInt(); }
	void readScalar(double *d)
	{ *d = readFloat(); }
	void readScalar(bool *b)
	{ *b = readBool(); }

public:	
	// Read a list of scalar data types (no lists of lists).
	template<typename T>
	void readTuple(std::vector<T> *tuple)
	{
		if (!data) throw InvalidItemException();
	
		Item itm;
		// Remove "set" prefix.
		if (sub(0, 3).isString("set"))
			// Remove "set" and enclosing [...] or (...)
			itm = sub(5, -3);
		else	// Remove enclosing [...] or (...)
			itm = sub(1, -2);

		if (len == 0)
			return; // tuple will remain empty
		// Iterate through the list.
		int i = 0;
		do {
			// Ignore leading spaces (trailing not ignored).
			while ((i < len) && (itm.data[i] == ' '))
				i++;
			int j = i;
			// TODO: invalid read here!
			while ((j < len) && (itm.data[j] != ','))
				j++;
			if (i < len) {
				// Read a scalar.
				T scalar;
				itm.sub(i, j-i).readScalar(&scalar);
                //std::cout << i << " " << j << " " << len << " " << scalar << std::endl;
				tuple->push_back(scalar);
			}
			i = j+1;
		} while (i < len);

		// (Results are returned implicitly)
	}

	Coord readCoord()
	{
		std::vector<double> tuple;
		readTuple(&tuple);
		if (tuple.size() != 2)
			throw new WrongTypeException();
		return Coord(tuple[0], tuple[1]);
	}
};

#endif	// __MESSAGE_PARSING__H__
