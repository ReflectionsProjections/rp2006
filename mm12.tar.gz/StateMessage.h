#ifndef	__STATE_MESSAGE__H__
#define	__STATE_MESSAGE__H__

#include "MessageParsing.h"
#include "Model.h"

class StateMessage : public State {
public:
	StateMessage(Packet &pkt);
	~StateMessage();
};

#endif	// __STATE_MESSAGE__H__
