#ifndef	__CLIENT__H__
#define	__CLIENT__H__

#include "Model.h"

/**
 * \mainpage
 * Each team starts out with Pirate Boats, Rum Runners, and a pier.
 * Your objective is to have the most software at then end of the game.
 * Games last for 300 turns.
 *
 * Pirate Boats are the main type of boat.  They can attack with cannons,
 * board and take over ships, and steal software.  To steal software you
 * go to the enemy pier, load up as much as you can carry, and then take
 * it back to your own pier.
 *
 * Rum Runners cannot attack or pick up software, but they can heal other
 * boats that they are next to.  A Rum Runner cannot heal itself and they
 * cannot be boarded.  They are faster than Pirate Boats.
 *
 * If you collide with an enemy boat you will take damage.  The angle of
 * the collision affects the damage done.  You do not take damage if you
 * collide with your own boats.
 *
 */

/**
 * \brief This is the class you will fill in
 * 
 * This is the class you will be subclassing to create your AI.
 */
class Client {
	public:
	
 Client(int pNumber) : playerNumber(pNumber) { }
		virtual ~Client() { }

		/**
		 * \brief This function will be called at the beginning of the game.
		 *
		 * You can implement this function if you want to do any sort of
		 * pre-game setup.
		 */
		virtual void init() { }
		/**
		 * \brief This function is called every 'frame' of the game.
		 *
		 * This is where you should be writing all of your code.
		 */
		virtual void tick() = 0;

		/**
		 * Update the current state of the game
		 */
		void updateState(const State& newState);

	protected:
		/**
		 * Contains every boat in the game
		 */
		std::vector<Boat*> allBoats;
		
		/**
		 * Contains all boats owned by the player
		 */
		std::vector<Boat*> myBoats;
		
		/**
		 * Contains all boats owned by the enemy
		 */
		std::vector<Boat*> enemyBoats;
		
		/**
		 * Contains every PirateBoat in the game
		 */
		std::vector<PirateBoat*> allPBoats;
		
		/**
		 * Contains all PirateBoats owned by the player
		 */
		std::vector<PirateBoat*> myPBoats;
        
		/**
		 * Contains all PirateBoats owned by the enemy
		 */
		std::vector<PirateBoat*> enemyPBoats;
		
		/**
		 * Points to the RumRunner owned by the player
		 */
		RumRunner* myRumRunner;
		/**
		 * Points to the RumRunner owned by the enemy
		 */
		RumRunner* enemyRumRunner;

		std::vector<Player*> players;
		Player* me;
		Player* enemy;
		
		Game* game;

	private:
		// Private b/c you should access it with me->id
		int playerNumber;
};

#endif	// __CLIENT__H__
