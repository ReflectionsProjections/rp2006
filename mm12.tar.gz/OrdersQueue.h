#ifndef	__ORDERS_QUEUE__H__
#define	__ORDERS_QUEUE__H__

#include <string>
#include <vector>

static inline std::string toStr(int x)
{
	char buf[256];
	sprintf(buf, "%i", x);
	return std::string(buf);
}

static inline std::string toStr(double x)
{
	char buf[256];
	sprintf(buf, "%lf", x);
	return std::string(buf);
}

class OrdersQueue {
public:
	typedef std::vector<std::string> Args;
	static OrdersQueue *create();

	virtual ~OrdersQueue() { }

	virtual void add(std::string name) = 0;
	virtual void add(std::string name, std::string arg0) = 0;
	virtual void add(std::string name, std::string arg0, std::string arg1) = 0;
	virtual void add(std::string name, Args args) = 0;
};

#endif	// __ORDERS_QUEUE__H__
