#ifndef	__MODEL__H__
#define	__MODEL__H__

#include "OrdersQueue.h"

/**
 * \brief Stores a 2D double coordinate
 */
class Coord {
public:
	double x, y;

	Coord() { }
	Coord(double x, double y) : x(x), y(y) { }
};

/**
 * \brief The "abstract" boat class
 *
 * The base class that PirateBoats and RumRunners inherit from.  Though it
 * doesn't have any pure virtual functions you should not actually have any
 * instances of this clas.
 */
class Boat {
protected:
	/**
	 * The order queue associated with this boat.  This is for
	 * communication with the server and you shouldn't need to use it
	 */
	OrdersQueue *ordersQueue;

	virtual void forceRTTI() { }
public:
	 /**
	  * \brief The id of the player who owns this boat.
	  */
	int player;

	/**
	 * \brief The id of the boat.
	 * When storing boat information across ticks, in a std::map for
	 * example, this is the key you should use as pointers will not
	 * be valid across function calls.
	 */
	int id;

	/**
	 * \brief The current location of the boat.
	 */
	Coord location;

	/**
	 * \brief A degree, 0 to 360, containing the boats current heading.
	 */
	double heading;
	
	/**
	 * \brief A degree, 0 to 360, containing the direction the boat.
	 * is moving towards.
	 */
	double goalHeading;
	
	/**
	 * \brief The boats current health.
	 */
	double health;

	/**
	 * \brief The boats speed.
	 */
	double speed;

	/**
	 * \brief The id of all the boats that this boat is currently
	 * colliding with.
	 */
	std::vector<int> collidesWith;

	virtual ~Boat() { }

	/**
	 * \brief Ignore this function.
	 */
	void setOrdersQueue(OrdersQueue *oq)
	{
		ordersQueue = oq;
	}

	/**
	 * \brief Sets a new heading for the boat.
	 * \param goalHeading the new heading in degrees.
	 */
	void turnAbsolute(double goalHeading)
	{
		//this->goalHeading = goalHeading;
		if (ordersQueue)
			ordersQueue->add("boat_turn_absolute", toStr(id),
			                 toStr(goalHeading));
	}
	/**
	 * \brief Sets the boats goal heading to the current heading.
	 */
	void stopTurning()
	{
		//goalHeading = heading;
		if (ordersQueue)
			ordersQueue->add("boat_stop_turning", toStr(id));
	}

	/**
	 * \brief Sets the current velocity.
	 * \param goalVelocity the target velocity.
	 */
	void velocity(double goalVelocity)
	{
		//this->goalVelocity = goalVelocity;
		if (ordersQueue)
			ordersQueue->add("boat_velocity", toStr(id),
			                 toStr(goalVelocity));
	}
};

/**
 * \brief The main boat type
 *
 * A PirateBoat is the main boat in your fleet.  It has a cannon it can
 * attack with, and has the capability to board and take over another ship.
 * You can steal software from the opposing team by loading it into a 
 * PirateBoat and taking it back to your base.
 */
class PirateBoat : public Boat {
public:
	/**
	 * \brief The vector index of the left cannon.
	 */
	const static unsigned int LEFT_CANNON = 0;

	/**
	 * \brief The vector index of the right cannon.
	 */
	const static unsigned int RIGHT_CANNON = 1;

	/**
	 * \brief The maximum possible speed.
	 */
	const static double MAX_SPEED = 2.0;

	/**
	 * \brief The maximum possible health.
	 */
	const static double MAX_HEALTH = 100.0;

	/**
	 * \brief The amount of software the boat currently has.
	 */
	double software;

	/**
	 * \brief The direction your cannons are pointed at.
	 */
	std::vector<double> fireAngle;

	/**
	 * \brief The amount of damage your cannons do.
	 */
	std::vector<double> fireDamage;

	/**
	 * \brief The range of your cannons.
	 */
	std::vector<double> fireRange;

	/**
	 * \brief How many turns you have to wait until you can fire the cannon
	 * again.
	 */
	std::vector<double> fireWait;

	/**
	 * \brief True if the cannon has just fired
	 */
	std::vector<bool> fire;

	/**
	 * \brief Loads software onto your boat.  You can only do 
	 * this when you are at a pier.
	 * \param amount the amount of software to load.
	 */
	void load(double amount)
	{
		if (ordersQueue)
			// Command name stays the same as in the base class
			ordersQueue->add("boat_load", toStr(id), toStr(amount));
	}

	/**
	 * \brief Unloads software from your boat.  You can only
	 * do this when you are at a pier.
	 * \param amount the amount of software to unload.
	 */
	void unload(double amount)
	{
		if (ordersQueue)
			ordersQueue->add("boat_unload", toStr(id), toStr(amount));
	}

	/**
	 * \brief Attempts to board another ship.  You can only do this
	 * when the ship has no health left.
	 * \param bid the id of the boat to board.
	 */
	void board(int bid)
	{
		//boarding = bid;
		if (ordersQueue)
			ordersQueue->add("boat_board", toStr(id), toStr(bid));
	}

	/**
	 * \brief Fires the left cannon.
	 */
	void fireLeft()
	{
		if (ordersQueue)
			ordersQueue->add("boat_fire_left", toStr(id));
	}

	/**
	 * \brief Fires the right cannon.
	 */
	void fireRight()
	{
		if (ordersQueue)
			ordersQueue->add("boat_fire_right", toStr(id));
	}
};

/**
 * \brief A medic boat
 * 
 * The RumRunner is the "medic" of your fleet.  It has the capability to
 * heal other boats.  It is also faster than the PirateBoats however it
 * does not have a cannon and cannot steal software.
 */
class RumRunner : public Boat {
public:

	/**
	 * \brief The maximum possible speed.
	 */
	const static double MAX_SPEED = 3.0;

	/**
	 * \brief The maximum possible health.
	 */
	const static double MAX_HEALTH = 100.0;


	/**
	 * \brief Heals a friendly boat.  You can only do this when you
	 * are next to the boat.
	 * \param bid The id of the boat you want to heal
	 */
	void heal(int bid)
	{
		if (ordersQueue)
			ordersQueue->add("boat_heal", toStr(id), toStr(bid));
	}
};

/**
 * \brief Stores some game information
 */
class Game {
public:
	/**
	 * \brief Current time
	 */
	int tm; 

 	/** 
	 * \brief Time when the game ends
	 */
	int maxTm;

 	/**
	 * \brief The player id of the winner
	 */
	int winner;

	int status;
};

/**
 * \brief Stores information pertaining to the player.
 *
 * Stores information pertaining to the player.
 */
class Player {
public:
	/**
	 * \brief The id of the player, used to identify their boats.
	 */
	int id;
	
	/**
	 * \brief The amount of software the player has obtained.
	 */
	double software;

	/**
	 * \brief The coordinates of the player pier.
	 */
	Coord pier;

	/**
	 * \brief The team colors.
	 */
	std::vector<int> color;

	/**
	 * \brief The team name.
	 */
	std::string name;
	
	/**
	 * The order queue associated with this player.  This is for
	 * communication with the server and you shouldn't need to use it.
	 */
	
	OrdersQueue *ordersQueue;
	/**
	 * \brief Ignore this function.
	 */
	void setOrdersQueue(OrdersQueue *oq)
	{
		ordersQueue = oq;
	}

	/**
	 * \brief Ask the server to display a chat message.
	 */
	void trashTalk(const char *text) {
		if (ordersQueue)
			ordersQueue->add("player_trashtalk", text);
	}

	/**
	 * \brief Set the team name.
	 *
	 * You should call this once, in your init function.
	 */
	void setName(const char *name) {
		if (ordersQueue)
			ordersQueue->add("player_name", name);
	}
};

/**
 * \brief Stores the current state of the game
 *
 * Stores the current state of the game, including players, boats, time
 * remaining, and current score.
 */
class State {
public:
	Game *game;
	std::vector<Player *> players;
	std::vector<Boat *>   boats;
};

#endif	// __MODEL__H__
